package dev.lvstrng.scalable.gui.components;

import dev.lvstrng.scalable.gui.Draw;
import dev.lvstrng.scalable.gui.Theme;
import dev.lvstrng.scalable.gui.Widgets;
import dev.lvstrng.scalable.module.Module;

/** One module tile in the grid: name, description, enable switch and a "more" button for settings. */
public final class ModuleCard {
	public static final float HEIGHT = 66f;

	public final Module module;
	public float x, y, w;

	private float hover, on, moreHover;

	public ModuleCard(Module module) {
		this.module = module;
		this.on = module.isEnabled() ? 1f : 0f;
	}

	public boolean hovered(float mx, float my) {
		return Widgets.inside(mx, my, x, y, w, HEIGHT);
	}

	private float moreCenterX() {
		return x + w - 16f - Widgets.SWITCH_W - 26f;
	}

	public boolean hasSettings() {
		return !module.getSettings().isEmpty();
	}

	public boolean overMore(float mx, float my) {
		return hasSettings() && hovered(mx, my) && Math.abs(mx - moreCenterX()) <= 15f;
	}

	public void render(float mx, float my, boolean interactive) {
		boolean over = interactive && hovered(mx, my);
		hover = Theme.approach(hover, over ? 1f : 0f, 14f);
		on = Theme.approach(on, module.isEnabled() ? 1f : 0f, 12f);
		moreHover = Theme.approach(moreHover, over && overMore(mx, my) ? 1f : 0f, 16f);

		float r = Theme.rad(11f);

		// body
		Draw.rrect(x, y, w, HEIGHT, r, Theme.white(10 + (int) (10 * hover)));
		if (on > 0.01f)
			Draw.rrect(x, y, w, HEIGHT, r, Theme.accent((int) (34 * on)));

		// border
		Draw.outline(x, y, w, HEIGHT, r, Theme.white(10 + (int) (8 * hover)));
		if (on > 0.01f)
			Draw.outline(x, y, w, HEIGHT, r, Theme.accent((int) (110 * on)));

		float textRight = (hasSettings() ? moreCenterX() - 18f : x + w - 16f - Widgets.SWITCH_W - 14f);
		float maxW = textRight - (x + 18f);

		int nameColor = Theme.mix(0xFFD9D9E0, 0xFFFFFFFF, Math.max(on, hover * 0.6f));
		Draw.text(Draw.fit(module.getName(), 0.78f, maxW), x + 18f, y + 25f, 0.78f, nameColor);
		Draw.text(Draw.fit(module.getDescription(), 0.5f, maxW), x + 18f, y + 46f, 0.5f, Theme.TEXT_2);

		// "more" (three dots)
		if (hasSettings()) {
			int dot = Theme.mix(Theme.TEXT_3, Theme.TEXT, Math.max(moreHover, 0f));
			float cx = moreCenterX();
			float cy = y + HEIGHT / 2f;
			if (moreHover > 0.01f)
				Draw.circle(cx, cy, 15f, Theme.white((int) (16 * moreHover)));
			Draw.circle(cx, cy - 6f, 2f, dot);
			Draw.circle(cx, cy, 2f, dot);
			Draw.circle(cx, cy + 6f, 2f, dot);
		}

		// switch
		Widgets.toggle(x + w - 16f - Widgets.SWITCH_W, y + (HEIGHT - Widgets.SWITCH_H) / 2f, on);
	}
}
