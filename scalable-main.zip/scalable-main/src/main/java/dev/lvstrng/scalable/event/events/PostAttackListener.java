package dev.lvstrng.scalable.event.events;

import dev.lvstrng.scalable.event.Event;
import dev.lvstrng.scalable.event.Listener;

import java.util.ArrayList;

/** Fired when MinecraftClient.doAttack has finished (the attack of this click is already sent). */
public interface PostAttackListener extends Listener {
	void onPostAttack();

	class PostAttackEvent extends Event<PostAttackListener> {

		@Override
		public void fire(ArrayList<PostAttackListener> listeners) {
			listeners.forEach(PostAttackListener::onPostAttack);
		}

		@Override
		public Class<PostAttackListener> getListenerType() {
			return PostAttackListener.class;
		}
	}
}
