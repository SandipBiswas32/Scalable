package dev.lvstrng.scalable.font;

public final class Fonts {
	public static GlyphPageFontRenderer QUICKSAND = GlyphPageFontRenderer.createFromID("/assets/scalable/font/font.ttf", 40, false, false, false);
}
