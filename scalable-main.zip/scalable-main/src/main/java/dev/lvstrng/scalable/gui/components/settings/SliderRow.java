package dev.lvstrng.scalable.gui.components.settings;

import dev.lvstrng.scalable.gui.Draw;
import dev.lvstrng.scalable.gui.Theme;
import dev.lvstrng.scalable.module.setting.NumberSetting;
import dev.lvstrng.scalable.utils.MathUtils;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public final class SliderRow extends SettingRow {
	private static final float PAD = 14f;

	private final NumberSetting setting;
	private boolean dragging;
	private float shown;

	public SliderRow(NumberSetting setting) {
		super(setting);
		this.setting = setting;
		this.shown = fraction();
	}

	@Override
	public float height() {
		return 58f;
	}

	private float fraction() {
		double range = setting.getMax() - setting.getMin();
		if (range <= 0) return 0f;
		return (float) Theme.clamp((float) ((setting.getValue() - setting.getMin()) / range), 0f, 1f);
	}

	private float trackX() {
		return x + PAD;
	}

	private float trackW() {
		return w - PAD * 2f;
	}

	private float trackY() {
		return y + 42f;
	}

	static String format(double value, double increment) {
		if (increment >= 1d) return String.valueOf((long) Math.round(value));
		int decimals = (int) Math.min(3, Math.max(1, Math.ceil(-Math.log10(increment))));
		return String.format(Locale.ROOT, "%." + decimals + "f", value);
	}

	@Override
	public void render(float mx, float my) {
		drawBackground(mx, my);
		shown = Theme.approach(shown, fraction(), 18f);

		Draw.text(Draw.fit(setting.getName(), 0.62f, w - 110f), x + PAD, y + 19f, 0.62f, Theme.TEXT);
		Draw.textRight(format(setting.getValue(), setting.getIncrement()), x + w - PAD, y + 19f, 0.58f,
				Theme.mix(Theme.TEXT_2, Theme.accent, dragging ? 1f : 0.55f));

		float tx = trackX(), tw = trackW(), ty = trackY();
		Draw.rrect(tx, ty - 3f, tw, 6f, 3f, Theme.white(22));

		float fillW = Math.max(6f, tw * shown);
		Draw.rrect(tx, ty - 3f, fillW, 6f, 3f, Theme.accent);

		float kx = tx + tw * shown;
		float kr = dragging ? 8f : 7f;
		Draw.circle(kx, ty + 0.5f, kr + 1f, Theme.black(70));
		Draw.circle(kx, ty, kr, 0xFFFFFFFF);
		Draw.circle(kx, ty, kr - 3.5f, Theme.accent);
	}

	private void slide(float mx) {
		double b = Theme.clamp((mx - trackX()) / trackW(), 0f, 1f);
		setting.setValue(MathUtils.roundToDecimal(b * (setting.getMax() - setting.getMin()) + setting.getMin(), setting.getIncrement()));
	}

	@Override
	public boolean mouseClicked(float mx, float my, int button) {
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && contains(mx, my) && my >= y + 24f) {
			dragging = true;
			slide(mx);
			return true;
		}
		return false;
	}

	@Override
	public void mouseDragged(float mx, float my) {
		if (dragging) slide(mx);
	}

	@Override
	public void mouseReleased(float mx, float my, int button) {
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) dragging = false;
	}

	@Override
	public void blur() {
		dragging = false;
	}

	@Override
	public void reset() {
		setting.setValue(setting.getOriginalValue());
	}
}
