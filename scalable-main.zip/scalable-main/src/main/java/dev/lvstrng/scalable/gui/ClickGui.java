package dev.lvstrng.scalable.gui;

import dev.lvstrng.scalable.Scalable;
import dev.lvstrng.scalable.gui.components.ModuleCard;
import dev.lvstrng.scalable.gui.components.SettingsPanel;
import dev.lvstrng.scalable.module.Category;
import dev.lvstrng.scalable.module.Module;
import dev.lvstrng.scalable.module.modules.client.ClickGUI;
import dev.lvstrng.scalable.utils.RenderUtils;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static dev.lvstrng.scalable.Scalable.mc;

/**
 * Main client screen.
 * <p>
 * Layout: sidebar (brand, categories, user) | header (title + search) | module card grid | hint bar.
 * Right click on a card (or the "..." button) opens the slide-in settings panel.
 */
public final class ClickGui extends Screen {
	// ---- layout (UI units, see Draw.s)
	private static final float PW = 1080f, PH = 660f;
	private static final float SIDE = 236f;
	private static final float HEAD = 80f;
	private static final float FOOT = 40f;
	private static final float PAD = 22f;
	private static final float GAP = 12f;
	private static final float SEARCH_W = 264f, SEARCH_H = 36f;
	private static final float CAT_TOP = 130f, CAT_H = 40f, CAT_GAP = 4f;

	private final List<ModuleCard> cards = new ArrayList<>();
	private final SettingsPanel settings = new SettingsPanel();
	private final float[] catHover = new float[Category.values().length];
	private final float[] catSelected = new float[Category.values().length];

	private Category selected = Category.values()[0];
	private String query = "";
	private boolean searchFocus;
	private float searchAnim, searchHover;

	private float gridScroll, gridTarget, gridMax;
	private float openAnim, dimAlpha;
	private long lastNano = System.nanoTime();

	// panel placement
	private float offX, offY;
	private float px, py;
	private boolean dragging;
	private float dragDX, dragDY;

	// per-frame grid geometry
	private float gridTop, gridBottom, gridLeft, gridRight;
	private List<ModuleCard> visible = List.of();

	public ClickGui() {
		super(Text.empty());

		for (Module module : Scalable.INSTANCE.getModuleManager().getModules())
			cards.add(new ModuleCard(module));
	}

	/* ------------------------------------------------------------ geometry */

	private float ux(double screenCoord) {
		return (float) (screenCoord * mc.getWindow().getScaleFactor() / Draw.s);
	}

	private void layout() {
		int fbW = mc.getWindow().getFramebufferWidth();
		int fbH = mc.getWindow().getFramebufferHeight();

		Draw.s = Theme.clamp(Math.min(fbW / 1750f, fbH / 980f), 0.5f, 1.35f);
		float uw = fbW / Draw.s, uh = fbH / Draw.s;

		float baseX = (uw - PW) / 2f, baseY = (uh - PH) / 2f;
		px = Theme.clamp(baseX + offX, -(PW - 140f), uw - 140f);
		py = Theme.clamp(baseY + offY, -20f, uh - 60f);
		offX = px - baseX;
		offY = py - baseY;

		gridLeft = px + SIDE + PAD;
		gridRight = px + PW - PAD;
		gridTop = py + HEAD + 16f;
		gridBottom = py + PH - FOOT;
	}

	private float searchX() {
		return px + PW - PAD - SEARCH_W;
	}

	private float searchY() {
		return py + (HEAD - SEARCH_H) / 2f;
	}

	private boolean overSearch(float mx, float my) {
		return Widgets.inside(mx, my, searchX(), searchY(), SEARCH_W, SEARCH_H);
	}

	private float catX() {
		return px + 14f;
	}

	private float catY(int i) {
		return py + CAT_TOP + i * (CAT_H + CAT_GAP);
	}

	private boolean searching() {
		return !query.isBlank();
	}

	private List<ModuleCard> filter() {
		String q = query.trim().toLowerCase(Locale.ROOT);
		List<ModuleCard> out = new ArrayList<>();
		for (ModuleCard card : cards) {
			if (q.isEmpty()) {
				if (card.module.getCategory() == selected) out.add(card);
			} else if (card.module.getName().toString().toLowerCase(Locale.ROOT).contains(q)) {
				out.add(card);
			}
		}
		return out;
	}

	private String userName() {
		try {
			return mc.getSession().getUsername();
		} catch (Throwable t) {
			return "Player";
		}
	}

	/* -------------------------------------------------------------- render */

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		if (mc.currentScreen != this) return;

		long now = System.nanoTime();
		float dt = Math.min(0.05f, (now - lastNano) / 1_000_000_000f);
		lastNano = now;

		if (Scalable.INSTANCE.previousScreen != null)
			Scalable.INSTANCE.previousScreen.render(context, 0, 0, delta);

		Draw.dt = dt;
		dimAlpha = Theme.approach(dimAlpha, ClickGUI.background.getValue() ? 200f : 0f, 10f);
		if (dimAlpha > 1f)
			context.fill(0, 0, mc.getWindow().getWidth(), mc.getWindow().getHeight(), ((int) dimAlpha) << 24);

		RenderUtils.unscaledProjection(context);
		try {
			Draw.ctx = context;
			layout();
			Theme.update();
			openAnim = Theme.approach(openAnim, 1f, 14f);
			Draw.fade = openAnim;

			float mx = ux(mouseX), my = ux(mouseY);
			drawPanel(mx, my);
		} finally {
			Draw.fade = 1f;
			RenderUtils.scaledProjection(context);
		}
	}

	private void drawPanel(float mx, float my) {
		float r = Theme.rad(16f);
		boolean blocked = settings.isOpen();

		// shadow + body
		Draw.rrect(px - 8f, py - 2f, PW + 16f, PH + 18f, r + 8f, Theme.black(28));
		Draw.rrect(px - 18f, py - 8f, PW + 36f, PH + 40f, r + 16f, Theme.black(14));
		Draw.rrect(px, py, PW, PH, r, Theme.panel());
		Draw.rrect(px, py, SIDE, PH, r, 0f, r, 0f, Theme.black(80));
		Draw.rect(px + SIDE, py + 14f, 1f, PH - 28f, Theme.white(12));

		drawSidebar(mx, my, blocked);
		drawHeader(mx, my, blocked);
		drawGrid(mx, my, blocked);
		drawFooter(mx, my);

		settings.setRegion(px + SIDE + 1f, py + HEAD + 1f, PW - SIDE - 1f, PH - HEAD - 1f, r);
		settings.render(mx, my);

		Draw.outline(px, py, PW, PH, r, Theme.white(18));
	}

	/* ------------------------------------------------------------- sidebar */

	private void drawSidebar(float mx, float my, boolean blocked) {
		// brand
		Draw.rrect(px + 22f, py + 22f, 42f, 42f, Theme.rad(12f), Theme.accent);
		Draw.gradientV(px + 22f, py + 26f, 42f, 34f, Theme.white(34), Theme.white(0));
		Draw.textCentered("S", px + 43f, py + 43f, 0.95f, 0xFFFFFFFF);
		Draw.text("Scalable", px + 76f, py + 34f, 0.8f, Theme.TEXT);
		Draw.text(Scalable.INSTANCE.getVersion().strip(), px + 76f, py + 55f, 0.44f, Theme.TEXT_3);

		Draw.rect(px + 22f, py + 88f, SIDE - 44f, 1f, Theme.white(12));
		Draw.text("MODULES", px + 26f, py + 110f, 0.42f, Theme.TEXT_3);

		Category[] cats = Category.values();
		for (int i = 0; i < cats.length; i++) {
			Category cat = cats[i];
			float x = catX(), y = catY(i), w = SIDE - 28f;

			boolean sel = !searching() && cat == selected;
			boolean hov = !blocked && Widgets.inside(mx, my, x, y, w, CAT_H);
			catHover[i] = Theme.approach(catHover[i], hov ? 1f : 0f, 14f);
			catSelected[i] = Theme.approach(catSelected[i], sel ? 1f : 0f, 14f);
			float h = catHover[i], s = catSelected[i];

			Draw.rrect(x, y, w, CAT_H, Theme.rad(10f), Theme.white((int) (9 * h)));
			if (s > 0.01f) {
				Draw.rrect(x, y, w, CAT_H, Theme.rad(10f), Theme.accent((int) (40 * s)));
				Draw.rrect(x, y + 11f, 3f, CAT_H - 22f, 1.5f, Theme.accent((int) (255 * s)));
			}

			Draw.circle(x + 22f, y + CAT_H / 2f, 4f, Theme.mix(Theme.TEXT_3, Theme.accent, s));
			Draw.text(cat.name, x + 38f, y + CAT_H / 2f, 0.68f, Theme.mix(Theme.TEXT_2, Theme.TEXT, Math.max(s, h)));

			int total = 0, on = 0;
			for (ModuleCard c : cards) {
				if (c.module.getCategory() != cat) continue;
				total++;
				if (c.module.isEnabled()) on++;
			}
			Draw.textRight(on + "/" + total, x + w - 14f, y + CAT_H / 2f, 0.46f, on > 0 ? Theme.accent : Theme.TEXT_3);
		}

		// user
		float fy = py + PH - 70f;
		Draw.rect(px + 22f, fy - 8f, SIDE - 44f, 1f, Theme.white(12));
		String name = userName();
		Draw.circle(px + 40f, fy + 28f, 17f, Theme.accent(70));
		Draw.textCentered(name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT), px + 40f, fy + 28f, 0.62f, Theme.TEXT);
		Draw.text(Draw.fit(name, 0.6f, SIDE - 100f), px + 66f, fy + 21f, 0.6f, Theme.TEXT);

		int active = Scalable.INSTANCE.getModuleManager().getEnabledModules().size();
		Draw.text(active + (active == 1 ? " module active" : " modules active"), px + 66f, fy + 39f, 0.44f, Theme.TEXT_3);
	}

	/* -------------------------------------------------------------- header */

	private void drawHeader(float mx, float my, boolean blocked) {
		float cx = px + SIDE + PAD + 4f;

		if (searching()) {
			Draw.text("Search", cx, py + 31f, 1f, Theme.TEXT);
			Draw.text(visible.size() + (visible.size() == 1 ? " result" : " results") + " in all categories", cx, py + 56f, 0.5f, Theme.TEXT_2);
		} else {
			int on = 0;
			for (ModuleCard c : visible) if (c.module.isEnabled()) on++;
			Draw.text(selected.name, cx, py + 31f, 1f, Theme.TEXT);
			Draw.text(visible.size() + " modules  |  " + on + " enabled", cx, py + 56f, 0.5f, Theme.TEXT_2);
		}

		// search box
		float sx = searchX(), sy = searchY();
		boolean over = !blocked && overSearch(mx, my);
		searchHover = Theme.approach(searchHover, over ? 1f : 0f, 14f);
		searchAnim = Theme.approach(searchAnim, searchFocus ? 1f : 0f, 16f);

		float r = Theme.rad(10f);
		Draw.rrect(sx, sy, SEARCH_W, SEARCH_H, r, Theme.white(10 + (int) (8 * searchHover)));
		Draw.outline(sx, sy, SEARCH_W, SEARCH_H, r, Theme.mix(Theme.white(14), Theme.accent(230), searchAnim));

		// magnifier icon: ring + handle
		float ix = sx + 20f, iy = sy + SEARCH_H / 2f - 1f;
		int ic = Theme.mix(Theme.TEXT_3, Theme.TEXT, Math.max(searchAnim, searchHover));
		Draw.circle(ix, iy, 6.5f, ic);
		Draw.circle(ix, iy, 4.5f, Theme.mix(0xFF1A1A22, 0xFF1A1A22, 0f));
		Draw.circle(ix + 6f, iy + 6f, 1.6f, ic);
		Draw.circle(ix + 4.5f, iy + 4.5f, 1.6f, ic);

		float tx = sx + 38f;
		float maxW = SEARCH_W - 38f - 14f;
		if (query.isEmpty()) {
			Draw.text("Search modules...", tx, sy + SEARCH_H / 2f, 0.56f, Theme.TEXT_3);
		} else {
			String shown = Draw.fitTail(query, 0.56f, maxW);
			Draw.text(shown, tx, sy + SEARCH_H / 2f, 0.56f, Theme.TEXT);
		}
		if (searchFocus && (System.currentTimeMillis() / 500L) % 2L == 0L) {
			float cw = query.isEmpty() ? 0f : Draw.textW(Draw.fitTail(query, 0.56f, maxW), 0.56f);
			Draw.rect(tx + cw + 1f, sy + SEARCH_H / 2f - 8f, 1.5f, 16f, Theme.accent);
		}

		Draw.rect(px + SIDE + 1f, py + HEAD, PW - SIDE - 2f, 1f, Theme.white(12));
	}

	/* ---------------------------------------------------------------- grid */

	private void drawGrid(float mx, float my, boolean blocked) {
		visible = filter();

		float cw = (gridRight - gridLeft - GAP) / 2f;
		int rowsCount = (visible.size() + 1) / 2;
		float contentH = rowsCount == 0 ? 0f : rowsCount * (ModuleCard.HEIGHT + GAP) - GAP;
		float viewH = gridBottom - gridTop;
		gridMax = Math.max(0f, contentH - viewH + 6f);
		gridTarget = Theme.clamp(gridTarget, 0f, gridMax);
		gridScroll = Theme.approach(gridScroll, gridTarget, 18f);

		float clipTop = py + HEAD + 1f;
		Draw.clip(px + SIDE + 1f, clipTop, PW - SIDE - 2f, gridBottom - clipTop);

		boolean mouseInGrid = !blocked && my >= clipTop && my <= gridBottom && mx >= px + SIDE && mx <= px + PW;

		if (visible.isEmpty()) {
			float cx = (gridLeft + gridRight) / 2f;
			Draw.textCentered("No modules found", cx, gridTop + 110f, 0.8f, Theme.TEXT_2);
			Draw.textCentered("Try a different search", cx, gridTop + 140f, 0.5f, Theme.TEXT_3);
		}

		for (int i = 0; i < visible.size(); i++) {
			ModuleCard card = visible.get(i);
			card.x = gridLeft + (i % 2) * (cw + GAP);
			card.y = gridTop - gridScroll + (i / 2) * (ModuleCard.HEIGHT + GAP);
			card.w = cw;

			if (card.y + ModuleCard.HEIGHT < clipTop || card.y > gridBottom) continue;
			card.render(mx, my, mouseInGrid);
		}
		Draw.unclip();

		// scrollbar
		if (gridMax > 0f) {
			float trackH = gridBottom - clipTop - 12f;
			float barH = Math.max(28f, trackH * (viewH / (viewH + gridMax)));
			float barY = clipTop + 6f + (trackH - barH) * (gridScroll / gridMax);
			Draw.rrect(px + PW - 9f, barY, 3f, barH, 1.5f, Theme.white(34));
		}
	}

	/* -------------------------------------------------------------- footer */

	private void drawFooter(float mx, float my) {
		float y = py + PH - FOOT;
		float cy = y + FOOT / 2f;
		float x = px + SIDE + PAD + 4f;

		Draw.rect(px + SIDE + 1f, y, PW - SIDE - 2f, 1f, Theme.white(10));

		ModuleCard hovered = null;
		if (!settings.isOpen())
			for (ModuleCard c : visible)
				if (c.hovered(mx, my) && my >= py + HEAD && my <= y) hovered = c;

		if (hovered != null) {
			Draw.text(Draw.fit(hovered.module.getName() + "  -  " + hovered.module.getDescription(), 0.46f, PW - SIDE - 2 * PAD - 8f), x, cy, 0.46f, Theme.TEXT_2);
			return;
		}

		hint(x, cy, "LMB", "Toggle");
		x += 112f;
		hint(x, cy, "RMB", "Settings");
		x += 124f;
		hint(x, cy, "Type", "Search");
		x += 112f;
		hint(x, cy, "Drag header", "Move");
	}

	private void hint(float x, float cy, String key, String action) {
		float kw = Draw.textW(key, 0.4f) + 14f;
		Draw.rrect(x, cy - 10f, kw, 20f, 6f, Theme.white(14));
		Draw.textCentered(key, x + kw / 2f, cy, 0.4f, Theme.TEXT);
		Draw.text(action, x + kw + 8f, cy, 0.46f, Theme.TEXT_3);
	}

	/* --------------------------------------------------------------- input */

	@Override
	protected void setInitialFocus() {
		if (client == null) {
			return;
		}
		super.setInitialFocus();
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		float mx = ux(click.x());
		float my = ux(click.y());
		int button = click.button();

		if (settings.isVisible() && settings.isOpen()) {
			searchFocus = false;
			settings.mouseClicked(mx, my, button);
			return true;
		}

		// search box
		if (overSearch(mx, my)) {
			if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) searchFocus = true;
			else if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
				query = "";
				gridTarget = 0;
			}
			return true;
		}
		searchFocus = false;

		// categories
		Category[] cats = Category.values();
		for (int i = 0; i < cats.length; i++) {
			if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && Widgets.inside(mx, my, catX(), catY(i), SIDE - 28f, CAT_H)) {
				selected = cats[i];
				query = "";
				gridTarget = 0;
				return true;
			}
		}

		// module cards
		if (my >= py + HEAD && my <= gridBottom) {
			for (ModuleCard card : visible) {
				if (!card.hovered(mx, my)) continue;

				if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
					if (card.overMore(mx, my)) settings.open(card.module);
					else card.module.toggle();
				} else if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
					settings.open(card.module);
				}
				return true;
			}
		}

		// drag the panel by its header / brand area
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT
				&& mx >= px && mx <= px + PW && my >= py && my <= py + HEAD) {
			dragging = true;
			dragDX = mx - px;
			dragDY = my - py;
			return true;
		}

		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseDragged(Click click, double deltaX, double deltaY) {
		float mx = ux(click.x());
		float my = ux(click.y());

		if (dragging) {
			float uw = mc.getWindow().getFramebufferWidth() / Draw.s;
			float uh = mc.getWindow().getFramebufferHeight() / Draw.s;
			offX = (mx - dragDX) - (uw - PW) / 2f;
			offY = (my - dragDY) - (uh - PH) / 2f;
			return true;
		}

		settings.mouseDragged(mx, my);
		return super.mouseDragged(click, deltaX, deltaY);
	}

	@Override
	public boolean mouseReleased(Click click) {
		float mx = ux(click.x());
		float my = ux(click.y());

		dragging = false;
		settings.mouseReleased(mx, my, click.button());
		return super.mouseReleased(click);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		float mx = ux(mouseX);
		float my = ux(mouseY);

		if (settings.isOpen()) {
			settings.mouseScrolled(mx, my, verticalAmount);
			return true;
		}

		if (mx >= px + SIDE && mx <= px + PW && my >= py + HEAD && my <= gridBottom)
			gridTarget = Theme.clamp(gridTarget - (float) verticalAmount * 52f, 0f, gridMax);

		return true;
	}

	@Override
	public boolean keyPressed(KeyInput keyInput) {
		int key = keyInput.key();
		int mods = keyInput.modifiers();

		// keybind listening / text fields inside the settings panel
		if (settings.isOpen()) {
			if (settings.keyPressed(key, mods)) return true;
			if (key == GLFW.GLFW_KEY_ESCAPE) {
				settings.close();
				return true;
			}
			return super.keyPressed(keyInput);
		}

		// search box
		if (searchFocus) {
			if (key == GLFW.GLFW_KEY_ESCAPE) {
				if (query.isEmpty()) searchFocus = false;
				else query = "";
				gridTarget = 0;
				return true;
			}
			if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
				searchFocus = false;
				return true;
			}
			if (key == GLFW.GLFW_KEY_BACKSPACE) {
				if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
				gridTarget = 0;
				return true;
			}
			boolean ctrl = (mods & GLFW.GLFW_MOD_CONTROL) != 0;
			if (ctrl && key == GLFW.GLFW_KEY_V) {
				query += mc.keyboard.getClipboard();
				gridTarget = 0;
				return true;
			}
			if (ctrl && key == GLFW.GLFW_KEY_A) {
				query = "";
				return true;
			}
		}

		return super.keyPressed(keyInput);
	}

	@Override
	public boolean charTyped(CharInput input) {
		if (settings.isOpen())
			return settings.charTyped(input) || super.charTyped(input);

		if (!input.isValidChar()) return super.charTyped(input);

		// start typing anywhere = search
		searchFocus = true;
		query += input.asString();
		gridTarget = 0;
		return true;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		Scalable.INSTANCE.getModuleManager().getModule(ClickGUI.class).setEnabledStatus(false);
		onGuiClose();
	}

	public void onGuiClose() {
		mc.setScreenAndRender(Scalable.INSTANCE.previousScreen);

		settings.reset();
		searchFocus = false;
		query = "";
		dragging = false;
		openAnim = 0f;
		dimAlpha = 0f;
		gridScroll = gridTarget = 0f;
	}
}
