package dev.lvstrng.scalable.event.events;

import dev.lvstrng.scalable.event.Event;
import dev.lvstrng.scalable.event.Listener;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;

/** Fired every tick the local player uses a kinetic weapon (spear). */
public interface ItemUsageTickListener extends Listener {
	void onItemUsageTick(ItemUsageTickEvent event);

	class ItemUsageTickEvent extends Event<ItemUsageTickListener> {
		public final LivingEntity user;
		public final ItemStack stack;
		public final int remainingUseTicks;

		public ItemUsageTickEvent(LivingEntity user, ItemStack stack, int remainingUseTicks) {
			this.user = user;
			this.stack = stack;
			this.remainingUseTicks = remainingUseTicks;
		}

		@Override
		public void fire(ArrayList<ItemUsageTickListener> listeners) {
			listeners.forEach(e -> e.onItemUsageTick(this));
		}

		@Override
		public Class<ItemUsageTickListener> getListenerType() {
			return ItemUsageTickListener.class;
		}
	}
}
