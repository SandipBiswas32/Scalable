package dev.lvstrng.scalable.gui.components;

import dev.lvstrng.scalable.gui.Draw;
import dev.lvstrng.scalable.gui.Theme;
import dev.lvstrng.scalable.gui.Widgets;
import dev.lvstrng.scalable.gui.components.settings.*;
import dev.lvstrng.scalable.module.Module;
import dev.lvstrng.scalable.module.setting.*;
import net.minecraft.client.input.CharInput;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Slide-in panel that shows every setting of one module. */
public final class SettingsPanel {
	private static final float W = 352f;
	private static final float HEAD = 68f;
	private static final float FOOT = 36f;
	private static final float GAP = 6f;
	private static final float PAD = 14f;

	private final Map<Module, List<SettingRow>> cache = new HashMap<>();

	private Module module;
	private List<SettingRow> rows = List.of();
	private boolean open;
	private float anim;
	private float scroll, scrollTarget, maxScroll;

	// overlay region (set by the GUI every frame) and resulting panel rectangle
	private float rx, ry, rw, rh, rBottomRadius;
	private float px, py, pw, ph;
	private float rowsTop, rowsBottom;
	private SettingRow hoveredRow;

	public boolean isOpen() {
		return open;
	}

	public boolean isVisible() {
		return module != null;
	}

	public Module getModule() {
		return module;
	}

	public void open(Module m) {
		if (m.getSettings().isEmpty()) return;
		if (module != m) {
			module = m;
			rows = cache.computeIfAbsent(m, this::buildRows);
			scroll = scrollTarget = 0;
		}
		open = true;
	}

	public void close() {
		open = false;
		for (SettingRow row : rows) row.blur();
	}

	/** Instantly hides the panel (used when the whole GUI closes). */
	public void reset() {
		close();
		module = null;
		anim = 0;
	}

	private List<SettingRow> buildRows(Module m) {
		List<SettingRow> out = new ArrayList<>();
		for (Setting<?> s : m.getSettings()) {
			if (s instanceof BooleanSetting b) out.add(new ToggleRow(b));
			else if (s instanceof NumberSetting n) out.add(new SliderRow(n));
			else if (s instanceof ModeSetting<?> md) out.add(new ModeRow(md));
			else if (s instanceof KeybindSetting k) out.add(new KeybindRow(m, k));
			else if (s instanceof StringSetting st) out.add(new StringRow(st));
			else if (s instanceof MinMaxSetting mm) out.add(new RangeRow(mm));
		}
		return out;
	}

	public void setRegion(float x, float y, float w, float h, float bottomRadius) {
		this.rx = x;
		this.ry = y;
		this.rw = w;
		this.rh = h;
		this.rBottomRadius = bottomRadius;
	}

	/* ---------------------------------------------------------------- render */

	public void render(float mx, float my) {
		anim = Theme.approach(anim, open ? 1f : 0f, 16f);
		if (!open && anim < 0.02f) {
			module = null;
			anim = 0;
		}
		if (module == null) return;

		float prevFade = Draw.fade;
		Draw.fade = prevFade * anim;

		// dim the grid behind the panel
		Draw.rrect(rx, ry, rw, rh, 0, 0, 0, rBottomRadius, Theme.black(150));

		pw = W;
		px = rx + rw - pw - 12f + (1f - anim) * 40f;
		py = ry + 12f;
		ph = rh - 24f;

		float r = Theme.rad(14f);
		Draw.rrect(px, py, pw, ph, r, 0xFF14141B);
		Draw.outline(px, py, pw, ph, r, Theme.white(18));

		// ---- header
		Draw.text(Draw.fit(module.getName(), 0.86f, pw - 36f - Widgets.SWITCH_W - 12f), px + 20f, py + 28f, 0.86f, Theme.TEXT);
		Draw.text(Draw.fit(module.getDescription(), 0.46f, pw - 40f), px + 20f, py + 52f, 0.46f, Theme.TEXT_2);
		float sw = px + pw - 20f - Widgets.SWITCH_W;
		headerToggle = Theme.approach(headerToggle, module.isEnabled() ? 1f : 0f, 14f);
		Widgets.toggle(sw, py + 17f, headerToggle);
		Draw.rect(px + 1f, py + HEAD, pw - 2f, 1f, Theme.white(14));

		// ---- rows
		rowsTop = py + HEAD + 8f;
		rowsBottom = py + ph - FOOT;
		boolean mouseInPanel = open && Widgets.inside(mx, my, px, py, pw, ph);
		boolean mouseInRows = mouseInPanel && my >= rowsTop && my <= rowsBottom;

		float y = rowsTop - scroll;
		float start = y;
		hoveredRow = null;

		Draw.clip(px + 1f, rowsTop, pw - 2f, rowsBottom - rowsTop);
		for (SettingRow row : rows) {
			float h = row.height();
			row.x = px + PAD;
			row.w = pw - PAD * 2f;
			row.y = y;
			row.hoverOk = mouseInRows;

			if (y + h >= rowsTop - 2f && y <= rowsBottom + 2f) {
				row.render(mx, my);
				if (mouseInRows && row.contains(mx, my)) hoveredRow = row;
			}
			y += h + GAP;
		}
		Draw.unclip();

		float total = (y - GAP) - start + 8f;
		maxScroll = Math.max(0f, total - (rowsBottom - rowsTop));
		scrollTarget = Theme.clamp(scrollTarget, 0f, maxScroll);
		scroll = Theme.approach(scroll, scrollTarget, 18f);

		// scrollbar
		if (maxScroll > 0f) {
			float trackH = rowsBottom - rowsTop;
			float barH = Math.max(24f, trackH * (trackH / (trackH + maxScroll)));
			float barY = rowsTop + (trackH - barH) * (scroll / maxScroll);
			Draw.rrect(px + pw - 6f, barY, 3f, barH, 1.5f, Theme.white(40));
		}

		// ---- footer hint
		Draw.rect(px + 1f, py + ph - FOOT, pw - 2f, 1f, Theme.white(14));
		String hint;
		if (hoveredRow != null && hoveredRow.setting.getDescription() != null && hoveredRow.setting.getDescription().length() > 0)
			hint = hoveredRow.setting.getDescription().toString();
		else if (hoveredRow != null)
			hint = "Backspace resets this setting to its default";
		else
			hint = "Esc to go back";
		Draw.text(Draw.fit(hint, 0.46f, pw - 40f), px + 20f, py + ph - FOOT / 2f, 0.46f, Theme.TEXT_2);

		Draw.fade = prevFade;
	}

	private float headerToggle;

	/* ----------------------------------------------------------------- input */

	public boolean wantsKeyboard() {
		if (!open) return false;
		for (SettingRow row : rows)
			if (row.wantsKeyboard()) return true;
		return false;
	}

	public void mouseClicked(float mx, float my, int button) {
		if (!open) return;

		SettingRow hit = null;

		// rows that are capturing input (listening / typing) get the click first
		for (SettingRow row : rows) {
			if (row.wantsKeyboard() && row.mouseClicked(mx, my, button)) {
				hit = row;
				break;
			}
		}

		if (hit == null) {
			boolean inPanel = Widgets.inside(mx, my, px, py, pw, ph);
			if (!inPanel) {
				close();
				return;
			}

			float sw = px + pw - 20f - Widgets.SWITCH_W;
			if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && Widgets.inside(mx, my, sw - 6f, py + 11f, Widgets.SWITCH_W + 12f, 34f)) {
				module.toggle();
				return;
			}

			if (my >= rowsTop && my <= rowsBottom) {
				for (SettingRow row : rows) {
					if (!row.wantsKeyboard() && row.contains(mx, my) && row.mouseClicked(mx, my, button)) {
						hit = row;
						break;
					}
				}
			}
		}

		for (SettingRow row : rows)
			if (row != hit) row.blur();
	}

	public void mouseReleased(float mx, float my, int button) {
		for (SettingRow row : rows) row.mouseReleased(mx, my, button);
	}

	public void mouseDragged(float mx, float my) {
		for (SettingRow row : rows) row.mouseDragged(mx, my);
	}

	public void mouseScrolled(float mx, float my, double vertical) {
		if (!open) return;
		scrollTarget = Theme.clamp(scrollTarget - (float) vertical * 46f, 0f, maxScroll);
	}

	public boolean isOverPanel(float mx, float my) {
		return module != null && Widgets.inside(mx, my, px, py, pw, ph);
	}

	/** @return true when the key was consumed. */
	public boolean keyPressed(int keyCode, int modifiers) {
		if (!open) return false;

		for (SettingRow row : rows)
			if (row.wantsKeyboard() && row.keyPressed(keyCode, modifiers)) return true;

		if (keyCode == GLFW.GLFW_KEY_BACKSPACE && hoveredRow != null) {
			hoveredRow.reset();
			return true;
		}
		return false;
	}

	public boolean charTyped(CharInput input) {
		if (!open) return false;
		for (SettingRow row : rows)
			if (row.wantsKeyboard() && row.charTyped(input)) return true;
		return false;
	}
}
