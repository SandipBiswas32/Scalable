package dev.lvstrng.scalable.mixin;

import dev.lvstrng.scalable.Scalable;
import dev.lvstrng.scalable.event.EventManager;
import dev.lvstrng.scalable.event.events.ButtonListener;
import dev.lvstrng.scalable.event.events.MouseMoveListener;
import dev.lvstrng.scalable.event.events.MouseUpdateListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {
	@Shadow @Final private MinecraftClient client;
	@Shadow public abstract double getX();
	@Shadow public abstract double getY();

	@Unique private double scalable$lastMouseX;
	@Unique private double scalable$lastMouseY;
	@Unique private boolean scalable$initialized;
	@Unique private final int[] scalable$buttonStates = new int[GLFW.GLFW_MOUSE_BUTTON_LAST + 1];

	@Inject(method = "tick", at = @At("TAIL"))
	private void onMouseUpdate(CallbackInfo ci) {
		EventManager.fire(new MouseUpdateListener.MouseUpdateEvent());
		long window = client.getWindow().getHandle();
		double x = getX();
		double y = getY();

		if (!scalable$initialized) {
			scalable$initialized = true;
			scalable$lastMouseX = x;
			scalable$lastMouseY = y;

			for (int button = 0; button < scalable$buttonStates.length; button++) {
				scalable$buttonStates[button] = GLFW.glfwGetMouseButton(window, button);
			}
			return;
		}

		if (x != scalable$lastMouseX || y != scalable$lastMouseY) {
			scalable$lastMouseX = x;
			scalable$lastMouseY = y;
			EventManager.fire(new MouseMoveListener.MouseMoveEvent(window, x, y));
		}

		for (int button = 0; button < scalable$buttonStates.length; button++) {
			int state = GLFW.glfwGetMouseButton(window, button);
			if (state != scalable$buttonStates[button]) {
				scalable$buttonStates[button] = state;
				EventManager.fire(new ButtonListener.ButtonEvent(button, window, state));
			}
		}
	}
}
