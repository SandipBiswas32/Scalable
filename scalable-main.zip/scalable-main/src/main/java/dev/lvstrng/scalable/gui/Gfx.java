package dev.lvstrng.scalable.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.lwjgl.BufferUtils;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Texture cache for the GUI.
 * <p>
 * Instead of drawing every glyph / every row of a rounded corner as its own GUI element (thousands per frame,
 * which is what dragged the FPS down), a whole string, circle or corner is rasterised ONCE into a small texture
 * and then drawn with a single quad per frame.
 */
public final class Gfx {
	private static final int MAX_TEXT = 400;
	private static final int MAX_SHAPES = 128;

	/** A texture is only destroyed a few frames after it was evicted, so a quad queued this frame never loses it. */
	private static final int DESTROY_DELAY = 4;

	public static final class Tex {
		final Identifier id;
		public final int w, h, pad, baseOff;

		Tex(Identifier id, int w, int h, int pad, int baseOff) {
			this.id = id;
			this.w = w;
			this.h = h;
			this.pad = pad;
			this.baseOff = baseOff;
		}
	}

	private static final class Pending {
		final Identifier id;
		final long frame;

		Pending(Identifier id, long frame) {
			this.id = id;
			this.frame = frame;
		}
	}

	private static final Map<String, Tex> TEXT = new LinkedHashMap<>(256, 0.75f, true);
	private static final Map<String, Tex> SHAPES = new LinkedHashMap<>(64, 0.75f, true);
	private static final List<Pending> PENDING = new ArrayList<>();
	private static int counter;
	private static long frame;

	private Gfx() {}

	/** Call once per rendered frame before anything is drawn. */
	public static void beginFrame() {
		frame++;
		if (PENDING.isEmpty()) return;

		Iterator<Pending> it = PENDING.iterator();
		while (it.hasNext()) {
			Pending p = it.next();
			if (frame - p.frame < DESTROY_DELAY) continue;
			try {
				MinecraftClient.getInstance().getTextureManager().destroyTexture(p.id);
			} catch (Throwable ignored) {
			}
			it.remove();
		}
	}

	/** Frees every cached texture (call when the window size / scale changes a lot or the GUI is closed). */
	public static void clear() {
		for (Tex t : TEXT.values()) PENDING.add(new Pending(t.id, frame));
		for (Tex t : SHAPES.values()) PENDING.add(new Pending(t.id, frame));
		TEXT.clear();
		SHAPES.clear();
	}

	/* --------------------------------------------------------------- upload */

	private static Tex upload(BufferedImage img, int pad, int baseOff) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(img, "png", baos);
			byte[] bytes = baos.toByteArray();

			ByteBuffer data = BufferUtils.createByteBuffer(bytes.length).put(bytes);
			data.flip();

			int index = ++counter;
			LinearTexture texture = new LinearTexture(() -> "scalable_gfx_" + index, NativeImage.read(data));
			texture.upload();

			Identifier id = Identifier.of("scalable", "gfx/" + index);
			MinecraftClient.getInstance().getTextureManager().registerTexture(id, texture);
			return new Tex(id, img.getWidth(), img.getHeight(), pad, baseOff);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	private static void trim(Map<String, Tex> map, int max) {
		if (map.size() <= max) return;
		Iterator<Map.Entry<String, Tex>> it = map.entrySet().iterator();
		while (map.size() > max && it.hasNext()) {
			Tex t = it.next().getValue();
			PENDING.add(new Pending(t.id, frame));
			it.remove();
		}
	}

	/* ---------------------------------------------------------------- text */

	public static Tex text(String s, float em) {
		String key = Math.round(em * 4f) + ":" + s;
		Tex t = TEXT.get(key);
		if (t == null) {
			GlyphBaker.Baked b = GlyphBaker.text(s, em);
			t = upload(b.img, b.pad, b.baseOff);
			if (t == null) return null;
			TEXT.put(key, t);
			trim(TEXT, MAX_TEXT);
		}
		return t;
	}

	/* --------------------------------------------------------------- shapes */

	/** Filled circle texture, diameter 2r. */
	public static Tex disc(int r) {
		String key = "d" + r;
		Tex t = SHAPES.get(key);
		if (t == null) {
			t = upload(GlyphBaker.disc(r), 0, 0);
			if (t == null) return null;
			SHAPES.put(key, t);
			trim(SHAPES, MAX_SHAPES);
		}
		return t;
	}

	/** Ring texture (outer radius r, thickness t), size 2r. */
	public static Tex ring(int r, int thickness) {
		String key = "r" + r + ":" + thickness;
		Tex t = SHAPES.get(key);
		if (t == null) {
			t = upload(GlyphBaker.ring(r, thickness), 0, 0);
			if (t == null) return null;
			SHAPES.put(key, t);
			trim(SHAPES, MAX_SHAPES);
		}
		return t;
	}

	/* -------------------------------------------------------------- drawing */

	/** Draws the whole texture with its top-left corner at (x, y). One pixel of texture = one pixel on screen. */
	public static void draw(DrawContext ctx, Tex t, int x, int y, int color) {
		if (t == null) return;
		ctx.drawTexture(RenderPipelines.GUI_TEXTURED, t.id, x, y, 0f, 0f, t.w, t.h, t.w, t.h, color);
	}

	/**
	 * Draws one quadrant of a disc / ring texture (qx, qy = 0 or 1) as a corner of size r x r at (x, y).
	 */
	public static void corner(DrawContext ctx, Tex t, int qx, int qy, int r, int x, int y, int color) {
		if (t == null || r <= 0) return;
		ctx.drawTexture(RenderPipelines.GUI_TEXTURED, t.id, x, y, (float) (qx * r), (float) (qy * r), r, r, r * 2, r * 2, color);
	}

	private static final class LinearTexture extends NativeImageBackedTexture {
		private LinearTexture(java.util.function.Supplier<String> label, NativeImage image) {
			super(label, image);
			this.sampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
		}
	}
}
