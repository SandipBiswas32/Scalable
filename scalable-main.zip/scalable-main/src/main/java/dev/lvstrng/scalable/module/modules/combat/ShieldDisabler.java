package dev.lvstrng.scalable.module.modules.combat;

import dev.lvstrng.scalable.event.events.AttackListener;
import dev.lvstrng.scalable.event.events.TickListener;
import dev.lvstrng.scalable.module.Category;
import dev.lvstrng.scalable.module.Module;
import dev.lvstrng.scalable.module.setting.BooleanSetting;
import dev.lvstrng.scalable.module.setting.KeybindSetting;
import dev.lvstrng.scalable.module.setting.MinMaxSetting;
import dev.lvstrng.scalable.module.setting.NumberSetting;
import dev.lvstrng.scalable.utils.EncryptedString;
import dev.lvstrng.scalable.utils.InventoryUtils;
import dev.lvstrng.scalable.utils.MouseSimulation;
import dev.lvstrng.scalable.utils.WorldUtils;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

import java.util.concurrent.ThreadLocalRandom;

public final class ShieldDisabler extends Module implements TickListener, AttackListener {
	private final MinMaxSetting hitDelay = new MinMaxSetting(EncryptedString.of("Hit Delay"), 0, 20, 1, 0, 0);
	private final MinMaxSetting switchDelay = new MinMaxSetting(EncryptedString.of("Switch Delay"), 0, 20, 1, 0, 0);
	private final NumberSetting disableChance = new NumberSetting(EncryptedString.of("Disable Chance"), 0, 100, 100, 1);
	private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
	private final BooleanSetting stun = new BooleanSetting(EncryptedString.of("Stun"), false);
	private final MinMaxSetting stunDelay = new MinMaxSetting(EncryptedString.of("Stun Delay"), 0, 20, 1, 0, 0);
	private final BooleanSetting clickSimulate = new BooleanSetting(EncryptedString.of("Click Simulation"), false);
	private final BooleanSetting requireHoldAxe = new BooleanSetting(EncryptedString.of("Hold Axe"), false);

	int previousSlot, hitClock, switchClock, attackWindow, lockClock;
	int stunClock, engagedClock;
	boolean axeSelected, skipFight, pendingStun, engaged;
	PlayerEntity stunTarget;

	public ShieldDisabler() {
		super(EncryptedString.of("Shield Disabler"),
				EncryptedString.of("Automatically disables your opponents shield"),
				-1,
				Category.COMBAT);

		addSettings(switchDelay, hitDelay, disableChance, switchBack, stun, stunDelay, clickSimulate, requireHoldAxe);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(AttackListener.class, this);

		hitClock = hitDelay.getRandomValueInt();
		switchClock = switchDelay.getRandomValueInt();
		previousSlot = -1;
		attackWindow = 0;
		lockClock = 0;
		axeSelected = false;
		skipFight = false;
		pendingStun = false;
		engaged = false;
		stunTarget = null;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(AttackListener.class, this);

		if (mc.player != null)
			switchBackIfNeeded();

		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.player == null)
			return;

		PlayerEntity target = getBlockingTarget();

		// Ek click se fight latch ho jaati hai, taaki delay ke dauraan click chhodne se kaam na ruke
		if (target != null && !engaged) {
			engaged = true;
			engagedClock = switchDelay.getMaxInt() + hitDelay.getMaxInt() + stunDelay.getMaxInt() + 30;
		}

		// Safety timeout: fight hamesha ke liye latch na rahe
		if (engaged && --engagedClock <= 0) {
			engaged = false;
			target = null;
		}

		if (attackWindow > 0)
			attackWindow--;

		if (lockClock > 0)
			lockClock--;

		// Stun ka extra hit pending hai: Stun Delay ke baad hit karo
		if (pendingStun) {
			boolean stillOnTarget = stunTarget != null
					&& stunTarget.isAlive()
					&& mc.currentScreen == null
					&& mc.crosshairTarget instanceof EntityHitResult hit
					&& hit.getEntity() == stunTarget;

			if (!stillOnTarget) {
				pendingStun = false;
				stunTarget = null;
			} else {
				if (stunClock > 0) {
					stunClock--;
					return;
				}

				if (clickSimulate.getValue())
					MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

				WorldUtils.hitEntity(stunTarget, true);

				pendingStun = false;
				stunTarget = null;
				return;
			}
		}

		// Target nahi (click nahi / shield down / crosshair hata) -> sab reset + purane slot par wapas
		if (target == null) {
			switchBackIfNeeded();
			return;
		}

		// Abhi hit kiya hai, server se shield tootne ka wait (warna har tick dobara hit hota)
		if (lockClock > 0)
			return;

		// Step 1: Switch Delay ke baad axe par jao (sirf ek baar per fight)
		if (!axeSelected) {
			if (previousSlot == -1)
				previousSlot = mc.player.getInventory().getSelectedSlot();

			if (switchClock > 0) {
				switchClock--;
				return;
			}

			if (!InventoryUtils.selectAxe())
				return;

			axeSelected = true;
			hitClock = hitDelay.getRandomValueInt();

			// Is fight ke liye ek baar chance roll: fail hua to axe par switch hoga par hit nahi
			skipFight = ThreadLocalRandom.current().nextDouble() * 100.0 >= disableChance.getValue();
		} else {
			// User ne beech mein slot badal diya ho to axe wapas select karo
			InventoryUtils.selectAxe();
		}

		// Chance fail hua: axe par switch ho chuka, ab is fight mein hit nahi
		if (skipFight)
			return;

		// Step 2: Hit Delay (axe select hone ke baad itne tick ruko)
		if (hitClock > 0) {
			hitClock--;
			return;
		}

		// Step 3: Pehla hit (shield disable karne wala)
		if (clickSimulate.getValue())
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

		WorldUtils.hitEntity(target, true);
		MaceSwap.onShieldAxeHit(target);

		// Stun on ho to extra hit: Stun Delay 0 = usi tick, warna itne tick baad
		if (stun.getValue()) {
			int delay = stunDelay.getRandomValueInt();

			if (delay <= 0) {
				if (clickSimulate.getValue())
					MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

				WorldUtils.hitEntity(target, true);
			} else {
				pendingStun = true;
				stunTarget = target;
				stunClock = delay - 1;
			}
		}

		// Server se shield band hone ki khabar aane tak (ping) dobara hit nahi
		lockClock = 5;
	}

	/**
	 * Target return karta hai agar user ne khud left click dabaya hai aur crosshair
	 * ek aise player par hai jo shield se block kar raha hai. Warna null.
	 */
	private PlayerEntity getBlockingTarget() {
		if (mc.currentScreen != null)
			return null;

		// Sirf sword, axe ya spear haath mein ho tab fight shuru ho
		if (!engaged && !isAllowedWeapon(mc.player.getMainHandStack().getItem()))
			return null;

		// Click sirf fight shuru karne ke liye chahiye, uske baad hold karna zaroori nahi
		if (!engaged && !isUserAttacking())
			return null;

		if (requireHoldAxe.getValue() && previousSlot == -1 && !(mc.player.getMainHandStack().getItem() instanceof AxeItem))
			return null;

		if (mc.player.isUsingItem())
			return null;

		if (!(mc.crosshairTarget instanceof EntityHitResult entityHit))
			return null;

		if (!(entityHit.getEntity() instanceof PlayerEntity player))
			return null;

		if (WorldUtils.isShieldFacingAway(player))
			return null;

		if (player.isHolding(Items.SHIELD) && player.isBlocking())
			return player;

		return null;
	}

	/**
	 * User khud attack kar raha hai ya nahi: attack key hold, mouse left press,
	 * ya abhi-abhi game ne user ka click (doAttack) process kiya.
	 * Isse mouse, touch/controller sab input methods par kaam karega.
	 */
	private boolean isUserAttacking() {
		return attackWindow > 0
				|| mc.options.attackKey.isPressed()
				|| GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
	}

	private boolean isAllowedWeapon(Item item) {
		String path = Registries.ITEM.getId(item).getPath();
		return path.endsWith("_sword") || path.endsWith("_axe") || path.endsWith("_spear");
	}

	private void switchBackIfNeeded() {
		if (previousSlot != -1) {
			if (switchBack.getValue())
				InventoryUtils.setInvSlot(previousSlot);

			previousSlot = -1;
		}

		axeSelected = false;
		skipFight = false;
		pendingStun = false;
		engaged = false;
		stunTarget = null;
		lockClock = 0;
		hitClock = hitDelay.getRandomValueInt();
		switchClock = switchDelay.getRandomValueInt();
	}

	@Override
	public void onAttack(AttackListener.AttackEvent event) {
		// User ka apna click note karo (cancel nahi karna)
		// Apne simulated click ko ignore karo, warna loop ban jayega
		if (!MouseSimulation.isMouseButtonPressed(GLFW.GLFW_MOUSE_BUTTON_LEFT))
			// Ek click kaafi: window itni lambi ki Switch/Hit/Stun delay poora ho jaye
			attackWindow = switchDelay.getMaxInt() + hitDelay.getMaxInt() + stunDelay.getMaxInt() + 4;
	}
}
