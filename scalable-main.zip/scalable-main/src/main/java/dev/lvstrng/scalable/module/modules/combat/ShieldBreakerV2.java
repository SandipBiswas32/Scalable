package dev.lvstrng.scalable.module.modules.combat;

import dev.lvstrng.scalable.event.events.AttackListener;
import dev.lvstrng.scalable.event.events.ItemUseListener;
import dev.lvstrng.scalable.event.events.TickListener;
import dev.lvstrng.scalable.mixin.MinecraftClientAccessor;
import dev.lvstrng.scalable.module.Category;
import dev.lvstrng.scalable.module.Module;
import dev.lvstrng.scalable.module.setting.BooleanSetting;
import dev.lvstrng.scalable.module.setting.MinMaxSetting;
import dev.lvstrng.scalable.module.setting.ModeSetting;
import dev.lvstrng.scalable.module.setting.NumberSetting;
import dev.lvstrng.scalable.module.setting.StringSetting;
import dev.lvstrng.scalable.utils.EncryptedString;
import dev.lvstrng.scalable.utils.InventoryUtils;
import dev.lvstrng.scalable.utils.MouseSimulation;
import dev.lvstrng.scalable.utils.TimerUtils;
import dev.lvstrng.scalable.utils.WorldUtils;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Shield Breaker V2 - EchoClient ke ShieldBreaker ka port.
 * Settings ke naam, order, range aur defaults Echo jaise hi hain.
 *
 * Mode Normal : crosshair blocking player par ho to khud axe pe swap + attack (click zaroori nahi)
 * Mode Click  : tu left click kare aur target shield se block kar raha ho to axe pe swap karke wahi click axe se jaata hai
 *
 * List wale settings (Item Whitelist, Return Items, Hotbar Whitelist, Return Slots) yahan
 * text box hain: items comma se alag likho (netherite_axe, diamond_sword), slots 1-9 (1,2,3).
 * Khali chhodo = sab allowed (Echo mein bhi empty list ka matlab yahi hai).
 */
public final class ShieldBreakerV2 extends Module implements TickListener, AttackListener, ItemUseListener {
	public enum Mode {Normal, Click}

	public enum ReturnTo {Item, Slot, Original}

	private static final Random RNG = new Random();

	private final ModeSetting<Mode> mode = new ModeSetting<>(EncryptedString.of("Mode"), Mode.Normal, Mode.class)
			.setDescription(EncryptedString.of("Normal: automatic | Click: swaps to axe when you click on a blocking player"));
	private final MinMaxSetting reactionDelay = new MinMaxSetting(EncryptedString.of("Reaction Delay"), 0, 500, 1, 0, 0)
			.setDescription(EncryptedString.of("ms before swapping to the axe (Normal)"));
	private final MinMaxSetting attackDelay = new MinMaxSetting(EncryptedString.of("Attack Delay"), 0, 500, 1, 0, 0)
			.setDescription(EncryptedString.of("ms between swapping to the axe and hitting (Normal)"));
	private final BooleanSetting autoSwap = new BooleanSetting(EncryptedString.of("Auto Swap"), true)
			.setDescription(EncryptedString.of("Swaps to an axe by itself (Normal)"));
	private final BooleanSetting swapBack = new BooleanSetting(EncryptedString.of("Swap Back"), false)
			.setDescription(EncryptedString.of("Swaps back after breaking the shield"));
	private final MinMaxSetting swapBackDelay = new MinMaxSetting(EncryptedString.of("Swap Back Delay"), 0, 20, 1, 1, 1)
			.setDescription(EncryptedString.of("Ticks to wait before swapping back"));
	private final ModeSetting<ReturnTo> returnTo = new ModeSetting<>(EncryptedString.of("Return To"), ReturnTo.Item, ReturnTo.class)
			.setDescription(EncryptedString.of("Where to swap back to: Item list, Slot list or the Original slot"));
	private final StringSetting returnSlots = new StringSetting(EncryptedString.of("Return Slots"), "")
			.setDescription(EncryptedString.of("Hotbar slots 1-9 (example: 1,2) used when Return To = Slot"));
	private final StringSetting returnItems = new StringSetting(EncryptedString.of("Return Items"), "")
			.setDescription(EncryptedString.of("Items (example: netherite_sword) used when Return To = Item"));
	private final BooleanSetting unblockOwnShield = new BooleanSetting(EncryptedString.of("Unblock Own Shield"), true)
			.setDescription(EncryptedString.of("Lowers your own shield so the hit lands (Normal)"));
	private final BooleanSetting stun = new BooleanSetting(EncryptedString.of("Stun"), false)
			.setDescription(EncryptedString.of("Extra hit right after the shield break"));
	private final StringSetting itemWhitelist = new StringSetting(EncryptedString.of("Item Whitelist"), "")
			.setDescription(EncryptedString.of("Only works while holding one of these items (empty = any)"));
	private final StringSetting hotbarWhitelist = new StringSetting(EncryptedString.of("Hotbar Whitelist"), "")
			.setDescription(EncryptedString.of("Only works on these hotbar slots 1-9 (empty = any)"));

	private final NumberSetting breakChance = new NumberSetting(EncryptedString.of("Shield Breaker Chance"), 0, 100, 100, 1)
			.setDescription(EncryptedString.of("Chance (%) that a blocking target gets the shield break"));
	private final NumberSetting stunChance = new NumberSetting(EncryptedString.of("Stun Chance"), 0, 100, 100, 1)
			.setDescription(EncryptedString.of("Chance (%) that the Stun hit happens after a shield break"));

	private final TimerUtils attackTimer = new TimerUtils();
	private final TimerUtils switchTimer = new TimerUtils();

	private PlayerEntity timedTarget;
	private PlayerEntity stunTarget;
	private int previousSlot = -1;
	private int swapBackClock;
	private int attackLockClock;
	private float reactionSample, attackSample;
	private boolean swapPending, attackDelayActive, switchDelayActive;
	private boolean ownShieldReleased, unblockTickPending, skipBreak;

	public ShieldBreakerV2() {
		super(EncryptedString.of("Shield Breaker V2"),
				EncryptedString.of("Breaks enemy shields"),
				-1,
				Category.COMBAT);

		addSettings(mode, reactionDelay, attackDelay, autoSwap, swapBack, swapBackDelay, returnTo,
				returnSlots, returnItems, unblockOwnShield, stun, itemWhitelist, hotbarWhitelist, breakChance, stunChance);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(AttackListener.class, this);
		eventManager.add(ItemUseListener.class, this);

		resetState();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(AttackListener.class, this);
		eventManager.remove(ItemUseListener.class, this);

		if (mc.player != null && swapPending)
			finishSwap();

		resetState();
		super.onDisable();
	}

	// ------------------------------------------------------------------ tick

	@Override
	public void onTick() {
		if (mc.player == null || mc.world == null)
			return;

		// apni shield ko dobara press hone se roko (jab tak user right click dabaye hai)
		if (ownShieldReleased) {
			if (isRightMouseDown())
				mc.options.useKey.setPressed(false);
			else if (!swapPending)
				ownShieldReleased = false;
		}

		// safety: agar shield nahi tuti to lock khatam hote hi dobara try
		if (attackLockClock > 0 && --attackLockClock == 0) {
			attackDelayActive = false;
			switchDelayActive = false;
		}

		// Swap Back Delay (ticks) poora hone par purane slot par wapas
		if (swapPending) {
			swapBackClock--;
			if (swapBackClock <= 0)
				finishSwap();
		}

		// Stun: shield tootne ke agle tick par ek aur hit
		if (stunTarget != null) {
			PlayerEntity target = stunTarget;
			stunTarget = null;

			if (target.isAlive() && mc.currentScreen == null
					&& mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() == target)
				WorldUtils.hitEntity(target, true);
		}

		if (mc.currentScreen != null) {
			resetShieldAttackTiming();
			return;
		}

		if (mode.getMode() == Mode.Normal)
			handleNormal();
	}

	private void handleNormal() {
		PlayerEntity target = findShieldTarget();

		if (target == null) {
			resetShieldAttackTiming();
			return;
		}

		if (!passesItemConditions())
			return;

		if (swapPending && !holdsAxe())
			return;

		if (target != timedTarget) {
			timedTarget = target;
			attackTimer.reset();
			switchTimer.reset();
			reactionSample = sample(reactionDelay);
			attackSample = sample(attackDelay);
			skipBreak = !roll(breakChance);
		}

		// Shield Breaker Chance fail: is target par shield nahi todni
		if (skipBreak)
			return;

		// Unblock Own Shield: pehle apni shield neeche karo, ek tick ruko, fir hit
		if (unblockTickPending) {
			unblockTickPending = false;
			return;
		}

		if (isBlockingSelf()) {
			if (unblockOwnShield.getValue() && !ownShieldReleased)
				releaseOwnShield();

			return;
		}

		if (target.hurtTime > latencyTicks())
			return;

		if (!holdsAxe()) {
			if (!autoSwap.getValue() || switchDelayActive)
				return;

			if (!attackTimer.hasReached(reactionSample))
				return;

			int slot = InventoryUtils.getAxeSlot();
			if (slot == -1)
				return;

			previousSlot = mc.player.getInventory().getSelectedSlot();
			InventoryUtils.setInvSlot(slot);
			switchDelayActive = true;
			switchTimer.reset();
			return;
		}

		if (attackDelayActive || attackLockClock > 0)
			return;

		if (!switchTimer.hasReached(attackSample))
			return;

		attack(target);
	}

	private void attack(PlayerEntity target) {
		WorldUtils.hitEntity(target, true);

		attackDelayActive = true;
		attackLockClock = 20;
		switchTimer.reset();

		if (stun.getValue() && roll(stunChance))
			stunTarget = target;

		queueSwapBack();
	}

	private void queueSwapBack() {
		if (swapBack.getValue() && previousSlot != -1) {
			swapPending = true;
			swapBackClock = Math.max(0, Math.round(sample(swapBackDelay)));
		} else {
			previousSlot = -1;
		}
	}

	private void finishSwap() {
		swapPending = false;

		if (swapBack.getValue()) {
			int slot = resolveReturnSlot();

			if (slot != -1)
				InventoryUtils.setInvSlot(slot);

			// Echo jaisa: swap back on ho to apni shield wapas utha lo (agar right click abhi bhi dabaya hai)
			if (ownShieldReleased && isRightMouseDown() && holdsShield()) {
				mc.options.useKey.setPressed(true);
				((MinecraftClientAccessor) mc).setItemUseCooldown(0);
			}
		}

		ownShieldReleased = false;
		previousSlot = -1;
	}

	private int resolveReturnSlot() {
		switch (returnTo.getMode()) {
			case Slot -> {
				List<Integer> slots = parseSlots(returnSlots.getValue());
				if (!slots.isEmpty())
					return slots.get(RNG.nextInt(slots.size()));
			}
			case Item -> {
				if (!returnItems.getValue().isBlank()) {
					for (int i = 0; i < 9; i++) {
						ItemStack stack = mc.player.getInventory().getStack(i);
						if (!stack.isEmpty() && itemInList(stack.getItem(), returnItems.getValue()))
							return i;
					}
				}
			}
			default -> {
			}
		}

		// Original ya list khali/match nahi: jis slot se aaye the wahi
		return previousSlot;
	}

	// ----------------------------------------------------------------- click

	@Override
	public void onAttack(AttackEvent event) {
		if (mode.getMode() != Mode.Click)
			return;

		if (mc.player == null || mc.world == null || mc.currentScreen != null)
			return;

		// apne simulated click ko ignore karo
		if (MouseSimulation.isMouseButtonPressed(GLFW.GLFW_MOUSE_BUTTON_LEFT))
			return;

		if (!passesItemConditions() || swapPending)
			return;

		if (mc.player.isUsingItem() && mc.player.getActiveHand() == Hand.OFF_HAND)
			return;

		PlayerEntity target = findShieldTarget();
		if (target == null || getAttackCooldown() > 0 || target.hurtTime > latencyTicks())
			return;

		// Shield Breaker Chance: har click par roll, fail to normal click jaayega
		if (!roll(breakChance))
			return;

		if (holdsAxe()) {
			if (stun.getValue() && roll(stunChance))
				stunTarget = target;

			return;
		}

		int slot = InventoryUtils.getAxeSlot();
		if (slot == -1)
			return;

		// doAttack ke HEAD par hain, isliye yahi click ab axe se jaayega
		previousSlot = mc.player.getInventory().getSelectedSlot();
		InventoryUtils.setInvSlot(slot);

		if (stun.getValue() && roll(stunChance))
			stunTarget = target;

		queueSwapBack();
	}

	@Override
	public void onItemUse(ItemUseEvent event) {
		// Unblock ke baad jab tak right click dabaya hai shield dobara na uthe
		if (ownShieldReleased && isRightMouseDown())
			event.cancel();
	}

	// --------------------------------------------------------------- helpers

	/** TriggerBot ke liye: crosshair par abhi shield se block karta player hai ya nahi (module on ho tab). */
	public boolean hasShieldTarget() {
		return isEnabled() && mc.player != null && mc.world != null && findShieldTarget() != null;
	}

	private PlayerEntity findShieldTarget() {
		if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof PlayerEntity target))
			return null;

		if (target == mc.player || !target.isAlive())
			return null;

		if (!target.isHolding(Items.SHIELD) || !target.isBlocking())
			return null;

		if (WorldUtils.isShieldFacingAway(target))
			return null;

		return target;
	}

	private boolean passesItemConditions() {
		if (ownShieldReleased || swapPending)
			return true;

		return heldItemAllowed() && hotbarSlotAllowed();
	}

	private boolean heldItemAllowed() {
		String list = itemWhitelist.getValue();
		if (list == null || list.isBlank())
			return true;

		return itemInList(mc.player.getMainHandStack().getItem(), list);
	}

	private boolean hotbarSlotAllowed() {
		List<Integer> slots = parseSlots(hotbarWhitelist.getValue());
		return slots.isEmpty() || slots.contains(mc.player.getInventory().getSelectedSlot());
	}

	private static boolean itemInList(Item item, String list) {
		String path = Registries.ITEM.getId(item).getPath();

		for (String entry : list.toLowerCase().split("[,;\\s]+")) {
			if (entry.isEmpty())
				continue;

			if (entry.startsWith("minecraft:"))
				entry = entry.substring(10);

			if (entry.equals(path))
				return true;
		}

		return false;
	}

	private static List<Integer> parseSlots(String text) {
		List<Integer> slots = new ArrayList<>();
		if (text == null)
			return slots;

		for (String part : text.split("[,;\\s]+")) {
			try {
				int n = Integer.parseInt(part.trim());
				if (n >= 1 && n <= 9 && !slots.contains(n - 1))
					slots.add(n - 1);
			} catch (NumberFormatException ignored) {
			}
		}

		return slots;
	}

	/** Echo ke FloatRangeSetting.sampleGaussian jaisa: mean = beech, deviation = range / 6, range ke andar clamp. */
	private static float sample(MinMaxSetting setting) {
		float lower = setting.getMinFloat();
		float upper = setting.getMaxFloat();

		if (upper <= lower)
			return lower;

		float mean = (lower + upper) / 2.0f;
		float deviation = (upper - lower) / 6.0f;
		float value = (float) (RNG.nextGaussian() * deviation + mean);

		return Math.max(lower, Math.min(upper, value));
	}

	private static boolean roll(NumberSetting chance) {
		return ThreadLocalRandom.current().nextDouble() * 100.0 < chance.getValue();
	}

	private boolean holdsAxe() {
		return WorldUtils.isAxe(mc.player.getMainHandStack());
	}

	private boolean holdsShield() {
		return mc.player.getMainHandStack().isOf(Items.SHIELD) || mc.player.getOffHandStack().isOf(Items.SHIELD);
	}

	private boolean isBlockingSelf() {
		return mc.player.isUsingItem() && mc.player.getActiveItem().isOf(Items.SHIELD);
	}

	private void releaseOwnShield() {
		mc.options.useKey.setPressed(false);
		mc.interactionManager.stopUsingItem(mc.player);
		ownShieldReleased = true;
		unblockTickPending = true;
	}

	private boolean isRightMouseDown() {
		return GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
	}

	private int getAttackCooldown() {
		return ((MinecraftClientAccessor) mc).getAttackCooldown();
	}

	private int latencyTicks() {
		if (mc.getNetworkHandler() == null || mc.player == null)
			return 0;

		var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
		return entry == null ? 0 : Math.min(entry.getLatency() / 50, 10);
	}

	private void resetShieldAttackTiming() {
		timedTarget = null;
		attackDelayActive = false;
		switchDelayActive = false;
		attackTimer.reset();
		switchTimer.reset();
	}

	private void resetState() {
		previousSlot = -1;
		swapBackClock = 0;
		attackLockClock = 0;
		swapPending = false;
		ownShieldReleased = false;
		unblockTickPending = false;
		skipBreak = false;
		stunTarget = null;
		resetShieldAttackTiming();
	}
}
