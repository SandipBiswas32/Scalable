package dev.lvstrng.scalable.utils.rotation;


public record Rotation(double yaw, double pitch) {
}
