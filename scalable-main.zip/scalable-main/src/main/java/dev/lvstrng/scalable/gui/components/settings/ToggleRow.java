package dev.lvstrng.scalable.gui.components.settings;

import dev.lvstrng.scalable.gui.Draw;
import dev.lvstrng.scalable.gui.Theme;
import dev.lvstrng.scalable.gui.Widgets;
import dev.lvstrng.scalable.module.setting.BooleanSetting;
import org.lwjgl.glfw.GLFW;

public final class ToggleRow extends SettingRow {
	private final BooleanSetting setting;
	private float p;

	public ToggleRow(BooleanSetting setting) {
		super(setting);
		this.setting = setting;
		this.p = setting.getValue() ? 1f : 0f;
	}

	@Override
	public float height() {
		return 46f;
	}

	@Override
	public void render(float mx, float my) {
		drawBackground(mx, my);
		p = Theme.approach(p, setting.getValue() ? 1f : 0f, 14f);

		Draw.text(Draw.fit(setting.getName(), 0.62f, w - 90f), x + 14f, y + height() / 2f, 0.62f, Theme.TEXT);
		Widgets.toggle(x + w - 14f - Widgets.SWITCH_W, y + (height() - Widgets.SWITCH_H) / 2f, p);
	}

	@Override
	public boolean mouseClicked(float mx, float my, int button) {
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && contains(mx, my)) {
			setting.toggle();
			return true;
		}
		return false;
	}

	@Override
	public void reset() {
		setting.setValue(setting.getOriginalValue());
	}
}
