package dev.lvstrng.scalable.gui;

/** Small reusable controls. */
public final class Widgets {
	public static final float SWITCH_W = 40f;
	public static final float SWITCH_H = 22f;

	private Widgets() {}

	/** Pill switch. p = 0 (off) .. 1 (on). */
	public static void toggle(float x, float y, float p) {
		int track = Theme.mix(Theme.OFF, Theme.accent, p);
		Draw.rrect(x, y, SWITCH_W, SWITCH_H, SWITCH_H / 2f, track);

		float knobX = x + 11f + (SWITCH_W - 22f) * p;
		Draw.circle(knobX, y + SWITCH_H / 2f, 8f, 0xFFFFFFFF);
	}

	public static boolean inside(float mx, float my, float x, float y, float w, float h) {
		return mx >= x && mx <= x + w && my >= y && my <= y + h;
	}
}
