package dev.lvstrng.scalable.mixin;

import dev.lvstrng.scalable.event.EventManager;
import dev.lvstrng.scalable.event.events.ItemUsageTickListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
	@Inject(method = "usageTick", at = @At("HEAD"))
	private void onUsageTick(World world, LivingEntity user, int remainingUseTicks, CallbackInfo ci) {
		if (!world.isClient() || user != MinecraftClient.getInstance().player)
			return;

		ItemStack stack = (ItemStack) (Object) this;
		if (stack.contains(DataComponentTypes.KINETIC_WEAPON))
			EventManager.fire(new ItemUsageTickListener.ItemUsageTickEvent(user, stack, remainingUseTicks));
	}
}
