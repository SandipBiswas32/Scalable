package dev.lvstrng.scalable.imixin;

public interface IKeyBinding {
	boolean isActuallyPressed();

	void resetPressed();
}
