package dev.lvstrng.scalable.gui;

import dev.lvstrng.scalable.font.Fonts;
import dev.lvstrng.scalable.module.modules.client.ClickGUI;
import dev.lvstrng.scalable.utils.RenderUtils;
import dev.lvstrng.scalable.utils.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;

import java.awt.Color;

/**
 * Tiny immediate-mode drawing layer for the GUI.
 * <p>
 * Every coordinate passed in here is in "UI units". UI units are converted to framebuffer pixels
 * with {@link #s}, so the whole interface scales with the window size and stays crisp.
 */
public final class Draw {
	public static DrawContext ctx;
	/** UI units -> framebuffer pixels. */
	public static float s = 1f;
	/** Global alpha multiplier (used for the open / close fades). */
	public static float fade = 1f;
	/** Frame time in seconds. */
	public static float dt = 0.016f;

	/**
	 * Height of one text line in "scale 1" units. Used to vertically centre text.
	 * If text looks a few pixels too high / low in-game, tune these two numbers.
	 */
	public static final float FONT_BOX_CUSTOM = 30f;
	public static final float FONT_BOX_VANILLA = 18f;

	private Draw() {}

	public static int px(float v) {
		return Math.round(v * s);
	}

	/** Applies the global fade to an ARGB colour. */
	public static int c(int argb) {
		int a = Math.round((argb >>> 24) * fade);
		a = Math.max(0, Math.min(255, a));
		return (a << 24) | (argb & 0xFFFFFF);
	}

	private static Color col(int argb) {
		return new Color(c(argb), true);
	}

	public static void rect(float x, float y, float w, float h, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;
		ctx.fill(px(x), px(y), px(x + w), px(y + h), a);
	}

	public static void gradientV(float x, float y, float w, float h, int top, int bottom) {
		ctx.fillGradient(px(x), px(y), px(x + w), px(y + h), c(top), c(bottom));
	}

	public static void rrect(float x, float y, float w, float h, float r, int argb) {
		rrect(x, y, w, h, r, r, r, r, argb);
	}

	/**
	 * Rounded rectangle with individual corner radii (top-left, top-right, bottom-left, bottom-right).
	 * Corners are anti-aliased cached textures and the rest is a few plain fills, so a card costs ~7 draw
	 * elements instead of dozens of one-pixel-row fills.
	 */
	public static void rrect(float x, float y, float w, float h, float tl, float tr, float bl, float br, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;

		int x0 = px(x), y0 = px(y), x1 = px(x + w), y1 = px(y + h);
		int W = x1 - x0, H = y1 - y0;
		if (W <= 0 || H <= 0) return;

		int max = Math.min(W, H) / 2;
		int rtl = Math.min(px(tl), max), rtr = Math.min(px(tr), max);
		int rbl = Math.min(px(bl), max), rbr = Math.min(px(br), max);

		if (rtl + rtr + rbl + rbr <= 0) {
			ctx.fill(x0, y0, x1, y1, a);
			return;
		}

		int left = Math.max(rtl, rbl), right = Math.max(rtr, rbr);
		if (W - left - right > 0) ctx.fill(x0 + left, y0, x1 - right, y1, a);
		side(x0, y0, x1, y1, left, rtl, rbl, false, a);
		side(x0, y0, x1, y1, right, rtr, rbr, true, a);
	}

	/** One side column of a rounded rect: the straight part plus its top / bottom corner. */
	private static void side(int x0, int y0, int x1, int y1, int sw, int rt, int rb, boolean right, int a) {
		if (sw <= 0) return;
		int sx0 = right ? x1 - sw : x0;
		int sx1 = right ? x1 : x0 + sw;

		if (y1 - rb > y0 + rt) ctx.fill(sx0, y0 + rt, sx1, y1 - rb, a);

		if (rt > 0) {
			Gfx.corner(ctx, Gfx.disc(rt), right ? 1 : 0, 0, rt, right ? x1 - rt : x0, y0, a);
			if (rt < sw) ctx.fill(right ? sx0 : x0 + rt, y0, right ? x1 - rt : sx1, y0 + rt, a);
		}
		if (rb > 0) {
			Gfx.corner(ctx, Gfx.disc(rb), right ? 1 : 0, 1, rb, right ? x1 - rb : x0, y1 - rb, a);
			if (rb < sw) ctx.fill(right ? sx0 : x0 + rb, y1 - rb, right ? x1 - rb : sx1, y1, a);
		}
	}

	public static void outline(float x, float y, float w, float h, float r, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;

		int x0 = px(x), y0 = px(y), x1 = px(x + w), y1 = px(y + h);
		int W = x1 - x0, H = y1 - y0;
		if (W <= 0 || H <= 0) return;

		int t = Math.max(1, Math.round(s));
		if (t * 2 >= Math.min(W, H)) {
			rrect(x, y, w, h, r, r, r, r, argb);
			return;
		}

		int rad = Math.min(px(r), Math.min(W, H) / 2);
		if (rad > 0 && rad < t) rad = t;

		if (rad <= 0) {
			ctx.fill(x0, y0, x1, y0 + t, a);
			ctx.fill(x0, y1 - t, x1, y1, a);
			ctx.fill(x0, y0 + t, x0 + t, y1 - t, a);
			ctx.fill(x1 - t, y0 + t, x1, y1 - t, a);
			return;
		}

		Gfx.Tex ring = Gfx.ring(rad, t);
		Gfx.corner(ctx, ring, 0, 0, rad, x0, y0, a);
		Gfx.corner(ctx, ring, 1, 0, rad, x1 - rad, y0, a);
		Gfx.corner(ctx, ring, 0, 1, rad, x0, y1 - rad, a);
		Gfx.corner(ctx, ring, 1, 1, rad, x1 - rad, y1 - rad, a);

		if (W - 2 * rad > 0) {
			ctx.fill(x0 + rad, y0, x1 - rad, y0 + t, a);
			ctx.fill(x0 + rad, y1 - t, x1 - rad, y1, a);
		}
		if (H - 2 * rad > 0) {
			ctx.fill(x0, y0 + rad, x0 + t, y1 - rad, a);
			ctx.fill(x1 - t, y0 + rad, x1, y1 - rad, a);
		}
	}

	public static void circle(float cx, float cy, float r, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;

		int rad = Math.max(1, Math.round(r * s));
		Gfx.draw(ctx, Gfx.disc(rad), px(cx) - rad, px(cy) - rad, a);
	}

	public static void clip(float x, float y, float w, float h) {
		ctx.enableScissor(px(x), px(y), px(x + w), px(y + h));
	}

	public static void unclip() {
		ctx.disableScissor();
	}

	/* ------------------------------------------------------------------ text */

	private static boolean custom() {
		return ClickGUI.customFont.getValue();
	}

	/** Draws text with its left edge at x and its vertical centre at cy. */
	public static void text(CharSequence str, float x, float cy, float scale, int argb) {
		if (str == null || str.length() == 0) return;
		int color = c(argb);
		if ((color >>> 24) < 4) return; // the font renderer treats tiny alpha as opaque

		float ts = scale * s;

		if (custom()) {
			// whole string = one cached texture, rasterised at the exact pixel size (no scaling, so it stays sharp)
			float em = Math.max(4f, Math.round(GlyphBaker.REF_EM * ts * 2f) / 2f);
			Gfx.Tex t = Gfx.text(str.toString(), em);
			if (t == null) return;
			int baseline = px(cy) + Math.round(em * GlyphBaker.BASELINE_K);
			Gfx.draw(ctx, t, px(x) - t.pad, baseline - t.baseOff, color);
			return;
		}

		Matrix3x2fStack m = ctx.getMatrices();
		m.pushMatrix();
		m.translate(px(x), px(cy) - FONT_BOX_VANILLA * ts / 2f);
		m.scale(ts * 2f, ts * 2f);
		ctx.drawText(MinecraftClient.getInstance().textRenderer, str.toString(), 0, 0, color, false);
		m.popMatrix();
	}

	public static void textRight(CharSequence str, float right, float cy, float scale, int argb) {
		text(str, right - textW(str, scale), cy, scale, argb);
	}

	public static void textCentered(CharSequence str, float cx, float cy, float scale, int argb) {
		text(str, cx - textW(str, scale) / 2f, cy, scale, argb);
	}

	private static final java.util.HashMap<String, Integer> WIDTHS = new java.util.HashMap<>();
	private static final java.util.HashMap<String, String> FITS = new java.util.HashMap<>();
	private static boolean cachedCustom = true;

	private static void checkCache() {
		boolean cu = custom();
		if (cu != cachedCustom || WIDTHS.size() > 2048 || FITS.size() > 2048) {
			WIDTHS.clear();
			FITS.clear();
			cachedCustom = cu;
		}
	}

	/** Width of the text in UI units (raw widths are cached, font measuring is slow). */
	public static float textW(CharSequence str, float scale) {
		if (str == null || str.length() == 0) return 0;
		checkCache();
		String key = str.toString();
		Integer w = WIDTHS.get(key);
		if (w == null) {
			w = custom() ? Math.round(GlyphBaker.measure(key) * 16f) : TextRenderer.getWidth(key) * 16;
			WIDTHS.put(key, w);
		}
		return w * scale / 16f;
	}

	/** Shortens the text with "..." so it fits into maxW UI units. */
	public static String fit(CharSequence str, float scale, float maxW) {
		String s0 = str == null ? "" : str.toString();
		if (textW(s0, scale) <= maxW) return s0;

		String key = s0 + '\u0001' + scale + '\u0001' + Math.round(maxW);
		String cached = FITS.get(key);
		if (cached != null) return cached;

		while (s0.length() > 1 && textW(s0 + "...", scale) > maxW)
			s0 = s0.substring(0, s0.length() - 1);
		s0 = s0 + "...";
		FITS.put(key, s0);
		return s0;
	}

	/** Same as {@link #fit} but keeps the END of the text (used for text fields while typing). */
	public static String fitTail(CharSequence str, float scale, float maxW) {
		String s0 = str == null ? "" : str.toString();
		while (s0.length() > 0 && textW(s0, scale) > maxW)
			s0 = s0.substring(1);
		return s0;
	}
}
