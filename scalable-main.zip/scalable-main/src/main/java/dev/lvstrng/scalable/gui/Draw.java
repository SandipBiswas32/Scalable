package dev.lvstrng.scalable.gui;

import dev.lvstrng.scalable.font.Fonts;
import dev.lvstrng.scalable.module.modules.client.ClickGUI;
import dev.lvstrng.scalable.utils.RenderUtils;
import dev.lvstrng.scalable.utils.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;

import java.awt.Color;

/**
 * Tiny immediate-mode drawing layer for the GUI.
 * <p>
 * Every coordinate passed in here is in "UI units". UI units are converted to framebuffer pixels
 * with {@link #s}, so the whole interface scales with the window size and stays crisp.
 */
public final class Draw {
	public static DrawContext ctx;
	/** UI units -> framebuffer pixels. */
	public static float s = 1f;
	/** Global alpha multiplier (used for the open / close fades). */
	public static float fade = 1f;
	/** Frame time in seconds. */
	public static float dt = 0.016f;

	/**
	 * Height of one text line in "scale 1" units. Used to vertically centre text.
	 * If text looks a few pixels too high / low in-game, tune these two numbers.
	 */
	public static final float FONT_BOX_CUSTOM = 30f;
	public static final float FONT_BOX_VANILLA = 18f;

	private Draw() {}

	public static int px(float v) {
		return Math.round(v * s);
	}

	/** Applies the global fade to an ARGB colour. */
	public static int c(int argb) {
		int a = Math.round((argb >>> 24) * fade);
		a = Math.max(0, Math.min(255, a));
		return (a << 24) | (argb & 0xFFFFFF);
	}

	private static Color col(int argb) {
		return new Color(c(argb), true);
	}

	public static void rect(float x, float y, float w, float h, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;
		ctx.fill(px(x), px(y), px(x + w), px(y + h), a);
	}

	public static void gradientV(float x, float y, float w, float h, int top, int bottom) {
		ctx.fillGradient(px(x), px(y), px(x + w), px(y + h), c(top), c(bottom));
	}

	public static void rrect(float x, float y, float w, float h, float r, int argb) {
		rrect(x, y, w, h, r, r, r, r, argb);
	}

	/** Horizontal inset of a corner at a given row (row 0 = outermost row of the corner). */
	private static int inset(int row, int r) {
		if (r <= 0 || row >= r) return 0;
		double dy = r - row - 0.5;
		return (int) Math.round(r - Math.sqrt(r * r - dy * dy));
	}

	/**
	 * Rounded rectangle with individual corner radii (top-left, top-right, bottom-left, bottom-right).
	 * Rows with the same shape are merged, so a card costs ~20 fill calls instead of one per pixel row.
	 */
	public static void rrect(float x, float y, float w, float h, float tl, float tr, float bl, float br, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;

		int x0 = px(x), y0 = px(y), x1 = px(x + w), y1 = px(y + h);
		int W = x1 - x0, H = y1 - y0;
		if (W <= 0 || H <= 0) return;

		int max = Math.min(W, H) / 2;
		int rtl = Math.min(px(tl), max), rtr = Math.min(px(tr), max);
		int rbl = Math.min(px(bl), max), rbr = Math.min(px(br), max);
		int top = Math.max(rtl, rtr), bot = Math.max(rbl, rbr);

		// top band
		int runStart = 0, pl = -1, pr = -1;
		for (int i = 0; i <= top; i++) {
			int li = i < top ? inset(i, rtl) : -2;
			int ri = i < top ? inset(i, rtr) : -2;
			if (li != pl || ri != pr) {
				if (pl != -1 && i > runStart) ctx.fill(x0 + pl, y0 + runStart, x1 - pr, y0 + i, a);
				runStart = i;
				pl = li;
				pr = ri;
			}
		}

		// middle
		if (H - top - bot > 0) ctx.fill(x0, y0 + top, x1, y1 - bot, a);

		// bottom band (rows are walked top -> bottom, corner row index counts from the bottom edge)
		runStart = 0;
		pl = -1;
		pr = -1;
		for (int t = 0; t <= bot; t++) {
			int j = bot - 1 - t;
			int li = t < bot ? inset(j, rbl) : -2;
			int ri = t < bot ? inset(j, rbr) : -2;
			if (li != pl || ri != pr) {
				if (pl != -1 && t > runStart) ctx.fill(x0 + pl, y1 - bot + runStart, x1 - pr, y1 - bot + t, a);
				runStart = t;
				pl = li;
				pr = ri;
			}
		}
	}

	public static void outline(float x, float y, float w, float h, float r, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;

		int x0 = px(x), y0 = px(y), x1 = px(x + w), y1 = px(y + h);
		int W = x1 - x0, H = y1 - y0;
		if (W <= 0 || H <= 0) return;

		int t = Math.max(1, Math.round(s));
		if (t * 2 >= Math.min(W, H)) {
			rrect(x, y, w, h, r, r, r, r, argb);
			return;
		}

		int rad = Math.min(px(r), Math.min(W, H) / 2);
		int inner = Math.max(0, rad - t);
		int band = Math.max(rad, t);

		// straight sides
		if (H - 2 * band > 0) {
			ctx.fill(x0, y0 + band, x0 + t, y1 - band, a);
			ctx.fill(x1 - t, y0 + band, x1, y1 - band, a);
		}

		// top + bottom bands (corner arcs and the horizontal edges)
		for (int pass = 0; pass < 2; pass++) {
			int runStart = 0, pli = -1, pli2 = -1;
			for (int i = 0; i <= band; i++) {
				int li = -2, li2 = -2;
				if (i < band) {
					int row = pass == 0 ? i : band - 1 - i; // distance from the outer edge
					li = inset(row, rad);
					li2 = row < t ? -1 : t + inset(row - t, inner); // -1 = solid edge row
				}
				if (li != pli || li2 != pli2) {
					if (pli != -1 && pli != -2 && i > runStart) {
						int ys = pass == 0 ? y0 + runStart : y1 - band + runStart;
						int ye = pass == 0 ? y0 + i : y1 - band + i;
						if (pli2 == -1) ctx.fill(x0 + pli, ys, x1 - pli, ye, a);
						else if (pli2 > pli) {
							ctx.fill(x0 + pli, ys, x0 + pli2, ye, a);
							ctx.fill(x1 - pli2, ys, x1 - pli, ye, a);
						}
					}
					runStart = i;
					pli = li;
					pli2 = li2;
				}
			}
		}
	}

	public static void circle(float cx, float cy, float r, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;

		int ox = px(cx), oy = px(cy);
		int rad = Math.max(1, Math.round(r * s));
		int runStart = -rad, prev = -1;
		for (int i = -rad; i <= rad; i++) {
			int half = -1;
			if (i < rad) {
				double dy = i + 0.5;
				double inner = rad * rad - dy * dy;
				half = inner > 0 ? (int) Math.round(Math.sqrt(inner)) : 0;
			}
			if (half != prev) {
				if (prev > 0 && i > runStart) ctx.fill(ox - prev, oy + runStart, ox + prev, oy + i, a);
				runStart = i;
				prev = half;
			}
		}
	}

	public static void clip(float x, float y, float w, float h) {
		ctx.enableScissor(px(x), px(y), px(x + w), px(y + h));
	}

	public static void unclip() {
		ctx.disableScissor();
	}

	/* ------------------------------------------------------------------ text */

	private static boolean custom() {
		return ClickGUI.customFont.getValue();
	}

	/** Draws text with its left edge at x and its vertical centre at cy. */
	public static void text(CharSequence str, float x, float cy, float scale, int argb) {
		if (str == null || str.length() == 0) return;
		int color = c(argb);
		if ((color >>> 24) < 4) return; // the font renderer treats tiny alpha as opaque

		boolean custom = custom();
		float box = custom ? FONT_BOX_CUSTOM : FONT_BOX_VANILLA;
		float ts = scale * s;

		Matrix3x2fStack m = ctx.getMatrices();
		m.pushMatrix();
		m.translate(px(x), px(cy) - box * ts / 2f);
		if (custom) {
			m.scale(ts, ts);
			Fonts.QUICKSAND.drawString(ctx, str, 0f, 0f, color);
		} else {
			m.scale(ts * 2f, ts * 2f);
			ctx.drawText(MinecraftClient.getInstance().textRenderer, str.toString(), 0, 0, color, false);
		}
		m.popMatrix();
	}

	public static void textRight(CharSequence str, float right, float cy, float scale, int argb) {
		text(str, right - textW(str, scale), cy, scale, argb);
	}

	public static void textCentered(CharSequence str, float cx, float cy, float scale, int argb) {
		text(str, cx - textW(str, scale) / 2f, cy, scale, argb);
	}

	private static final java.util.HashMap<String, Integer> WIDTHS = new java.util.HashMap<>();
	private static final java.util.HashMap<String, String> FITS = new java.util.HashMap<>();
	private static boolean cachedCustom = true;

	private static void checkCache() {
		boolean cu = custom();
		if (cu != cachedCustom || WIDTHS.size() > 2048 || FITS.size() > 2048) {
			WIDTHS.clear();
			FITS.clear();
			cachedCustom = cu;
		}
	}

	/** Width of the text in UI units (raw widths are cached, font measuring is slow). */
	public static float textW(CharSequence str, float scale) {
		if (str == null || str.length() == 0) return 0;
		checkCache();
		String key = str.toString();
		Integer w = WIDTHS.get(key);
		if (w == null) {
			w = TextRenderer.getWidth(key);
			WIDTHS.put(key, w);
		}
		return w * scale;
	}

	/** Shortens the text with "..." so it fits into maxW UI units. */
	public static String fit(CharSequence str, float scale, float maxW) {
		String s0 = str == null ? "" : str.toString();
		if (textW(s0, scale) <= maxW) return s0;

		String key = s0 + '\u0001' + scale + '\u0001' + Math.round(maxW);
		String cached = FITS.get(key);
		if (cached != null) return cached;

		while (s0.length() > 1 && textW(s0 + "...", scale) > maxW)
			s0 = s0.substring(0, s0.length() - 1);
		s0 = s0 + "...";
		FITS.put(key, s0);
		return s0;
	}

	/** Same as {@link #fit} but keeps the END of the text (used for text fields while typing). */
	public static String fitTail(CharSequence str, float scale, float maxW) {
		String s0 = str == null ? "" : str.toString();
		while (s0.length() > 0 && textW(s0, scale) > maxW)
			s0 = s0.substring(1);
		return s0;
	}
}
