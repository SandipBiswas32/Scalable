package dev.lvstrng.scalable.gui;

import dev.lvstrng.scalable.font.Fonts;
import dev.lvstrng.scalable.module.modules.client.ClickGUI;
import dev.lvstrng.scalable.utils.RenderUtils;
import dev.lvstrng.scalable.utils.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;

import java.awt.Color;

/**
 * Tiny immediate-mode drawing layer for the GUI.
 * <p>
 * Every coordinate passed in here is in "UI units". UI units are converted to framebuffer pixels
 * with {@link #s}, so the whole interface scales with the window size and stays crisp.
 */
public final class Draw {
	public static DrawContext ctx;
	/** UI units -> framebuffer pixels. */
	public static float s = 1f;
	/** Global alpha multiplier (used for the open / close fades). */
	public static float fade = 1f;
	/** Frame time in seconds. */
	public static float dt = 0.016f;

	/**
	 * Height of one text line in "scale 1" units. Used to vertically centre text.
	 * If text looks a few pixels too high / low in-game, tune these two numbers.
	 */
	public static final float FONT_BOX_CUSTOM = 30f;
	public static final float FONT_BOX_VANILLA = 18f;

	private Draw() {}

	public static int px(float v) {
		return Math.round(v * s);
	}

	/** Applies the global fade to an ARGB colour. */
	public static int c(int argb) {
		int a = Math.round((argb >>> 24) * fade);
		a = Math.max(0, Math.min(255, a));
		return (a << 24) | (argb & 0xFFFFFF);
	}

	private static Color col(int argb) {
		return new Color(c(argb), true);
	}

	public static void rect(float x, float y, float w, float h, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;
		ctx.fill(px(x), px(y), px(x + w), px(y + h), a);
	}

	public static void gradientV(float x, float y, float w, float h, int top, int bottom) {
		ctx.fillGradient(px(x), px(y), px(x + w), px(y + h), c(top), c(bottom));
	}

	public static void rrect(float x, float y, float w, float h, float r, int argb) {
		rrect(x, y, w, h, r, r, r, r, argb);
	}

	/** Rounded rectangle with individual corner radii (top-left, top-right, bottom-left, bottom-right). */
	public static void rrect(float x, float y, float w, float h, float tl, float tr, float bl, float br, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;
		RenderUtils.renderRoundedQuad(ctx, new Color(a, true),
				px(x), px(y), px(x + w), px(y + h),
				px(tl), px(tr), px(bl), px(br), 20);
	}

	public static void outline(float x, float y, float w, float h, float r, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;
		RenderUtils.renderRoundedOutline(ctx, new Color(a, true),
				px(x), px(y), px(x + w), px(y + h),
				px(r), px(r), px(r), px(r), Math.max(1, Math.round(s)), 20);
	}

	public static void circle(float cx, float cy, float r, int argb) {
		int a = c(argb);
		if ((a >>> 24) == 0) return;
		RenderUtils.renderCircle(ctx, new Color(a, true), px(cx), px(cy), r * s, 20);
	}

	public static void clip(float x, float y, float w, float h) {
		ctx.enableScissor(px(x), px(y), px(x + w), px(y + h));
	}

	public static void unclip() {
		ctx.disableScissor();
	}

	/* ------------------------------------------------------------------ text */

	private static boolean custom() {
		return ClickGUI.customFont.getValue();
	}

	/** Draws text with its left edge at x and its vertical centre at cy. */
	public static void text(CharSequence str, float x, float cy, float scale, int argb) {
		if (str == null || str.length() == 0) return;
		int color = c(argb);
		if ((color >>> 24) < 4) return; // the font renderer treats tiny alpha as opaque

		boolean custom = custom();
		float box = custom ? FONT_BOX_CUSTOM : FONT_BOX_VANILLA;
		float ts = scale * s;

		Matrix3x2fStack m = ctx.getMatrices();
		m.pushMatrix();
		m.translate(px(x), px(cy) - box * ts / 2f);
		if (custom) {
			m.scale(ts, ts);
			Fonts.QUICKSAND.drawString(ctx, str, 0f, 0f, color);
		} else {
			m.scale(ts * 2f, ts * 2f);
			ctx.drawText(MinecraftClient.getInstance().textRenderer, str.toString(), 0, 0, color, false);
		}
		m.popMatrix();
	}

	public static void textRight(CharSequence str, float right, float cy, float scale, int argb) {
		text(str, right - textW(str, scale), cy, scale, argb);
	}

	public static void textCentered(CharSequence str, float cx, float cy, float scale, int argb) {
		text(str, cx - textW(str, scale) / 2f, cy, scale, argb);
	}

	/** Width of the text in UI units. */
	public static float textW(CharSequence str, float scale) {
		if (str == null || str.length() == 0) return 0;
		return TextRenderer.getWidth(str) * scale;
	}

	/** Shortens the text with "..." so it fits into maxW UI units. */
	public static String fit(CharSequence str, float scale, float maxW) {
		String s0 = str == null ? "" : str.toString();
		if (textW(s0, scale) <= maxW) return s0;
		while (s0.length() > 1 && textW(s0 + "...", scale) > maxW)
			s0 = s0.substring(0, s0.length() - 1);
		return s0 + "...";
	}

	/** Same as {@link #fit} but keeps the END of the text (used for text fields while typing). */
	public static String fitTail(CharSequence str, float scale, float maxW) {
		String s0 = str == null ? "" : str.toString();
		while (s0.length() > 0 && textW(s0, scale) > maxW)
			s0 = s0.substring(1);
		return s0;
	}
}
