package dev.lvstrng.scalable.utils;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttackRangeComponent;
import net.minecraft.component.type.KineticWeaponComponent;
import net.minecraft.component.type.PiercingWeaponComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.dragon.EnderDragonPart;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/** Predicts what a charging kinetic weapon (spear) will hit this tick. Port of EchoClient's KineticAttackEvaluation. */
public final class KineticUtils {
	public record Hit(Entity target, boolean damage, boolean knockback, boolean dismount, float damageAmount, boolean onCooldown) {
		public boolean isAvailable() {
			return !onCooldown;
		}
	}

	private static final Map<Entity, Long> CONTACTS = new WeakHashMap<>();
	private static int previousElapsedUseTicks = Integer.MAX_VALUE;

	private KineticUtils() {}

	public static List<Hit> findTargets(LivingEntity user, ItemStack stack, int remainingUseTicks) {
		int elapsed = stack.getMaxUseTime(user) - remainingUseTicks;
		if (elapsed <= previousElapsedUseTicks)
			CONTACTS.clear();
		previousElapsedUseTicks = elapsed;

		KineticWeaponComponent weapon = stack.get(DataComponentTypes.KINETIC_WEAPON);
		if (weapon == null)
			return List.of();

		int activeTicks = elapsed;
		if (activeTicks < weapon.delayTicks())
			return List.of();
		activeTicks -= weapon.delayTicks();

		Vec3d direction = user.getRotationVec(1.0F);
		double attackerSpeed = direction.dotProduct(KineticWeaponComponent.getAmplifiedMovement(user));
		float speedScale = user instanceof PlayerEntity ? 1.0F : 0.2F;
		AttackRangeComponent range = user.getAttackRange();

		double attackDamage = user.getAttributeBaseValue(EntityAttributes.ATTACK_DAMAGE);
		long time = user.getEntityWorld().getTime();
		Collection<EntityHitResult> contacts = ProjectileUtil.collectPiercingCollisions(user, range,
				t -> PiercingWeaponComponent.canHit(user, t), RaycastContext.ShapeType.COLLIDER)
				.map(blockHit -> List.<EntityHitResult>of(), entityHits -> entityHits);

		List<Hit> results = new ArrayList<>();
		for (EntityHitResult contact : contacts) {
			Entity target = contact.getEntity();
			if (target instanceof EnderDragonPart part)
				target = part.owner;

			Long previous = CONTACTS.get(target);
			boolean onCooldown = previous != null && time - previous < weapon.contactCooldownTicks();
			if (!onCooldown)
				CONTACTS.put(target, time);

			double targetSpeed = direction.dotProduct(KineticWeaponComponent.getAmplifiedMovement(target));
			double approachSpeed = Math.max(0.0, attackerSpeed - targetSpeed);

			boolean dismount = weapon.dismountConditions().isPresent()
					&& weapon.dismountConditions().get().isSatisfied(activeTicks, attackerSpeed, approachSpeed, speedScale);
			boolean knockback = weapon.knockbackConditions().isPresent()
					&& weapon.knockbackConditions().get().isSatisfied(activeTicks, attackerSpeed, approachSpeed, speedScale);
			boolean damage = weapon.damageConditions().isPresent()
					&& weapon.damageConditions().get().isSatisfied(activeTicks, attackerSpeed, approachSpeed, speedScale);

			if (dismount || knockback || damage) {
				float damageAmount = (float) attackDamage + (float) MathHelper.floor(approachSpeed * weapon.damageMultiplier());
				results.add(new Hit(target, damage, knockback, dismount, damageAmount, onCooldown));
			}
		}

		return results;
	}
}
