package dev.lvstrng.scalable.module.modules.combat;

import dev.lvstrng.scalable.Scalable;
import dev.lvstrng.scalable.event.events.AttackListener;
import dev.lvstrng.scalable.event.events.ItemUsageTickListener;
import dev.lvstrng.scalable.event.events.PostAttackListener;
import dev.lvstrng.scalable.event.events.TickListener;
import dev.lvstrng.scalable.mixin.KeyBindingAccessor;
import dev.lvstrng.scalable.module.Category;
import dev.lvstrng.scalable.module.Module;
import dev.lvstrng.scalable.module.setting.BooleanSetting;
import dev.lvstrng.scalable.module.setting.MinMaxSetting;
import dev.lvstrng.scalable.module.setting.ModeSetting;
import dev.lvstrng.scalable.module.setting.NumberSetting;
import dev.lvstrng.scalable.module.setting.StringSetting;
import dev.lvstrng.scalable.utils.EncryptedString;
import dev.lvstrng.scalable.utils.InventoryUtils;
import dev.lvstrng.scalable.utils.KineticUtils;
import dev.lvstrng.scalable.utils.WorldUtils;
import net.minecraft.client.util.InputUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Mace Swap - EchoClient ke MaceSwap ka port.
 * Settings ke naam, order, range aur defaults Echo jaise hi hain.
 *
 * - Tu kisi mob/player par left click kare to mace (priority order ke hisaab se) haath mein aata hai,
 *   hit mace se jaata hai, phir Delay (ticks) ke baad wapas (Return To).
 * - Stun Slam: Shield Breaker / Shield Disabler (axe) shield tod de to Stun Switch Delay ke baad mace se hit.
 * - Spear D-tap: spear charge karte waqt jab spear ka hit Minimum Damage se zyada hone wala ho to mace se follow-up hit.
 *
 * Echo ki list / group wale settings yahan text box hain:
 * - Item Whitelist / Return Items: items comma se alag (netherite_axe, mace). "sword", "axe" jaisa suffix likho to
 *   saari swords / axes match ho jaati hain.
 * - Hotbar Whitelist / Return Slots: slots 1-9 (1,2,3).
 * - Priority Order: upar se neeche pehla usable mace jeet-ta hai. Naam comma se likho:
 *   Breach, Wind Burst, Density, Fallback. Jo naam list mein nahi wo Echo mein "disabled" jaisa hai
 *   (us enchant wala mace use nahi hota). Har ek ki Fall Distance range neeche alag setting hai.
 * Khali list = sab allowed (Echo mein bhi yahi).
 */
public final class MaceSwap extends Module implements TickListener, AttackListener, PostAttackListener, ItemUsageTickListener {
	public enum ReturnTo {Original, Slot, Item}

	private static final float SMASH_THRESHOLD = 1.5f;
	private static final float BREACH_UPPER_BOUND = 7.0f;
	private static final float MAXIMUM_FALL_DISTANCE = 20.0f;
	private static final String[] RANGE_NAMES = {"Breach", "Wind Burst", "Density", "Fallback"};
	private static final Random RNG = new Random();

	private final MinMaxSetting delay = new MinMaxSetting(EncryptedString.of("Delay"), 0, 20, 1, 1, 1)
			.setDescription(EncryptedString.of("Ticks the mace stays in your hand before swapping back"));
	private final StringSetting itemWhitelist = new StringSetting(EncryptedString.of("Item Whitelist"), "")
			.setDescription(EncryptedString.of("Only swaps while holding one of these items (empty = any)"));
	private final StringSetting hotbarWhitelist = new StringSetting(EncryptedString.of("Hotbar Whitelist"), "")
			.setDescription(EncryptedString.of("Only swaps from these hotbar slots 1-9 (empty = any)"));
	private final StringSetting priorityOrder = new StringSetting(EncryptedString.of("Priority Order"), "Breach, Wind Burst, Density")
			.setDescription(EncryptedString.of("Top to bottom, the first entry with a usable mace inside its fall distance wins. Names not listed are disabled (they block maces carrying them)"));
	private final MinMaxSetting breachRange = new MinMaxSetting(EncryptedString.of("Breach Fall Distance"), 0, MAXIMUM_FALL_DISTANCE, 0.1, SMASH_THRESHOLD, BREACH_UPPER_BOUND)
			.setDescription(EncryptedString.of("Blocks fallen: Breach mace is used inside this range"));
	private final MinMaxSetting windBurstRange = new MinMaxSetting(EncryptedString.of("Wind Burst Fall Distance"), 0, MAXIMUM_FALL_DISTANCE, 0.1, SMASH_THRESHOLD, MAXIMUM_FALL_DISTANCE)
			.setDescription(EncryptedString.of("Blocks fallen: Wind Burst mace is used inside this range"));
	private final MinMaxSetting densityRange = new MinMaxSetting(EncryptedString.of("Density Fall Distance"), 0, MAXIMUM_FALL_DISTANCE, 0.1, SMASH_THRESHOLD, MAXIMUM_FALL_DISTANCE)
			.setDescription(EncryptedString.of("Blocks fallen: Density mace is used inside this range"));
	private final MinMaxSetting fallbackRange = new MinMaxSetting(EncryptedString.of("Fallback Fall Distance"), 0, MAXIMUM_FALL_DISTANCE, 0.1, 0, MAXIMUM_FALL_DISTANCE)
			.setDescription(EncryptedString.of("Blocks fallen: a mace without Breach / Wind Burst / Density (add Fallback to Priority Order)"));
	private final BooleanSetting stunSlam = new BooleanSetting(EncryptedString.of("Stun Slam"), true)
			.setDescription(EncryptedString.of("After an axe breaks a shield, swaps to the mace and hits"));
	private final MinMaxSetting stunSwitchDelay = new MinMaxSetting(EncryptedString.of("Stun Switch Delay"), 1, 20, 1, 1, 1)
			.setDescription(EncryptedString.of("Total ticks from the shield disable to attack with the mace"));
	private final BooleanSetting spearDTap = new BooleanSetting(EncryptedString.of("Spear D-tap"), true)
			.setDescription(EncryptedString.of("Swaps to the mace and hits right after a spear hit"));
	private final NumberSetting minimumDamage = new NumberSetting(EncryptedString.of("Minimum Damage"), 0, 35, 10, 1)
			.setDescription(EncryptedString.of("Spear D-tap only when the spear hit does at least this much damage"));
	private final ModeSetting<ReturnTo> returnTo = new ModeSetting<>(EncryptedString.of("Return To"), ReturnTo.Original, ReturnTo.class)
			.setDescription(EncryptedString.of("Where to go after the mace hit: Original slot, Slot list or Item list"));
	private final StringSetting returnSlots = new StringSetting(EncryptedString.of("Return Slots"), "")
			.setDescription(EncryptedString.of("Hotbar slots 1-9 (example: 1,2) used when Return To = Slot"));
	private final StringSetting returnItems = new StringSetting(EncryptedString.of("Return Items"), "")
			.setDescription(EncryptedString.of("Items (example: netherite_sword) used when Return To = Item"));

	private final BooleanSetting debug = new BooleanSetting(EncryptedString.of("Debug"), false)
			.setDescription(EncryptedString.of("Shows (above the hotbar) why Mace Swap did or did not swap on a click"));

	// active swap (Echo: DeferredActionQueue entry)
	private boolean swapActive;
	private int baselineSlot = -1;
	private long expireTick;
	private boolean restoreOriginal;
	private boolean switchBlocked;
	private boolean restoreUseKey;

	// pending mace attack (Spear D-tap / Stun Slam)
	private boolean attackPending;
	private int pendingMaceSlot = -1;
	private int pendingTargetId = -1;
	private boolean requireSameTarget = true;
	private long lastSwapTick = -1L;

	// scheduled stun swap
	private int scheduledMaceSlot = -1;
	private int scheduledTargetId = -1;
	private long scheduledSwapTick = -1L;

	// a click that is about to hit a shield-blocking player with an axe
	private boolean shieldClick;

	public MaceSwap() {
		super(EncryptedString.of("Mace Swap"),
				EncryptedString.of("Swaps to mace for attacks"),
				-1,
				Category.COMBAT);

		addSettings(delay, itemWhitelist, hotbarWhitelist, priorityOrder, breachRange, windBurstRange, densityRange, fallbackRange,
				stunSlam, stunSwitchDelay, spearDTap, minimumDamage, returnTo, returnSlots, returnItems, debug);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(AttackListener.class, this);
		eventManager.add(PostAttackListener.class, this);
		eventManager.add(ItemUsageTickListener.class, this);

		resetAll();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(AttackListener.class, this);
		eventManager.remove(PostAttackListener.class, this);
		eventManager.remove(ItemUsageTickListener.class, this);

		if (mc.player != null && swapActive)
			finishSwap();

		resetAll();
		super.onDisable();
	}

	// ------------------------------------------------------------------ tick

	@Override
	public void onTick() {
		if (isOutsideWorld()) {
			resetAll();
			return;
		}

		switchBlocked = false;

		// Delay poora hua: mace se wapas
		if (swapActive && mc.player.age >= expireTick)
			finishSwap();

		if (mc.currentScreen != null || !stunSlam.getValue()) {
			clearScheduledSwap();
		} else if (scheduledMaceSlot != -1 && mc.player.age >= scheduledSwapTick) {
			int slot = scheduledMaceSlot;
			int targetId = scheduledTargetId;
			clearScheduledSwap();
			prepareStunAttack(slot, targetId);
		}

		if (attackPending)
			runPendingAttack();
	}

	// ----------------------------------------------------------------- click

	@Override
	public void onAttack(AttackEvent event) {
		shieldClick = false;

		if (isOutsideWorld() || mc.currentScreen != null)
			return;

		if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof LivingEntity target))
			return;

		// Stun Slam: axe se shield wale player par click -> hit ke baad mace schedule hoga
		if (stunSlam.getValue() && target instanceof PlayerEntity player && isBlockingTarget(player)
				&& WorldUtils.isAxe(mc.player.getMainHandStack()))
			shieldClick = true;

		int slot = findEligibleMace(target);
		if (slot == -1)
			return;

		// doAttack ke HEAD par hain, isliye yahi click ab mace se jaayega
		suspendItemUse();
		beginSwap(slot, sampleTicks(delay));
	}

	@Override
	public void onPostAttack() {
		if (isOutsideWorld())
			return;

		// Echo DeferredActionQueue: attack ke baad (movement packet tak) naya switch nahi
		switchBlocked = true;

		// Delay 0: usi tick mein mace se wapas
		if (swapActive && mc.player.age >= expireTick)
			finishSwap();

		if (shieldClick) {
			shieldClick = false;
			scheduleStun(mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity living ? living : null);
		}
	}

	// ------------------------------------------------------------ spear d-tap

	@Override
	public void onItemUsageTick(ItemUsageTickEvent event) {
		if (isOutsideWorld() || !spearDTap.getValue())
			return;

		boolean selected = false;
		for (KineticUtils.Hit hit : KineticUtils.findTargets(event.user, event.stack, event.remainingUseTicks)) {
			if (!hit.isAvailable())
				continue;

			float damage = hit.damage() ? hit.damageAmount() : 0.0f;
			if (!selected && !(damage < minimumDamage.getValueFloat()) && hit.target() instanceof LivingEntity target)
				selected = requestMaceSwap(target);
		}
	}

	/** Echo: requestMaceSwap. Mace par swap karke agle tick mein usi target par hit. */
	public boolean requestMaceSwap(LivingEntity target) {
		int slot = findEligibleMace(target);
		if (slot == -1)
			return false;

		suspendItemUse();
		pendingMaceSlot = slot;
		pendingTargetId = target.getId();
		requireSameTarget = true;
		attackPending = true;
		lastSwapTick = mc.player.age;
		return true;
	}

	// ------------------------------------------------------------- stun slam

	/** ShieldBreakerV2 / ShieldDisabler axe se shield par hit karne ke baad ise bulate hain. */
	public static void onShieldAxeHit(LivingEntity target) {
		MaceSwap module = Scalable.INSTANCE.getModuleManager().getModule(MaceSwap.class);
		if (module != null && module.isEnabled())
			module.scheduleStun(target);
	}

	/** Shield Breaker ko swap back tab tak rokne ke liye (Echo: Targets.shieldBreakActive). */
	public static boolean isStunPending() {
		MaceSwap module = Scalable.INSTANCE.getModuleManager().getModule(MaceSwap.class);
		return module != null && module.isEnabled() && (module.scheduledMaceSlot != -1 || module.attackPending || module.swapActive);
	}

	private void scheduleStun(LivingEntity target) {
		if (isOutsideWorld() || !stunSlam.getValue() || target == null)
			return;

		if (!WorldUtils.isAxe(mc.player.getMainHandStack()) || !isValidTarget(target))
			return;

		int slot = findPriorityMace();
		if (slot == -1)
			return;

		int ticks = Math.max(1, Math.round(sample(stunSwitchDelay)));
		scheduledMaceSlot = slot;
		scheduledTargetId = target.getId();
		scheduledSwapTick = mc.player.age + ticks;
	}

	private void prepareStunAttack(int slot, int targetId) {
		suspendItemUse();
		pendingMaceSlot = mc.player.getInventory().getSelectedSlot() == slot ? -1 : slot;
		pendingTargetId = targetId;
		requireSameTarget = false;
		attackPending = true;
		lastSwapTick = mc.player.age;
		runPendingAttack();
	}

	// --------------------------------------------------------- pending attack

	private void runPendingAttack() {
		boolean recent = mc.player.age - lastSwapTick <= 2L;
		int slot = pendingMaceSlot;
		int targetId = pendingTargetId;
		boolean checkTarget = requireSameTarget;
		resetPendingAttack();

		if (!recent || mc.currentScreen != null) {
			restoreItemUse();
			return;
		}

		if (slot != -1 && mc.player.getInventory().getSelectedSlot() != slot) {
			if (!beginSwap(slot, sampleTicks(delay))) {
				restoreItemUse();
				return;
			}
		}

		boolean holdingMace = mc.player.getMainHandStack().getItem() == Items.MACE;
		boolean validTarget = !checkTarget || isCrosshairTargetValid(targetId);

		if (holdingMace && validTarget && mc.crosshairTarget instanceof EntityHitResult hit) {
			WorldUtils.hitEntity(hit.getEntity(), true);
			switchBlocked = true;
		}

		if (swapActive && mc.player.age >= expireTick)
			finishSwap();
		else if (!swapActive)
			restoreItemUse();
	}

	private boolean isCrosshairTargetValid(int targetId) {
		if (targetId < 0 || !(mc.crosshairTarget instanceof EntityHitResult hit))
			return false;

		return hit.getEntity().getId() == targetId
				&& hit.getEntity() instanceof LivingEntity target
				&& isValidTarget(target);
	}

	// ----------------------------------------------------------- swap handling

	private boolean beginSwap(int slot, int delayTicks) {
		if (slot < 0 || slot > 8 || swapActive)
			return false;

		int current = mc.player.getInventory().getSelectedSlot();
		if (current == slot || switchBlocked)
			return false;

		swapActive = true;
		baselineSlot = current;
		expireTick = mc.player.age + Math.max(0, delayTicks);
		restoreOriginal = returnTo.getMode() == ReturnTo.Original;

		InventoryUtils.setInvSlot(slot);
		return true;
	}

	private void finishSwap() {
		if (!swapActive)
			return;

		swapActive = false;

		if (restoreOriginal && baselineSlot >= 0 && baselineSlot <= 8)
			InventoryUtils.setInvSlot(baselineSlot);

		baselineSlot = -1;
		onSwapEnded();
	}

	private void onSwapEnded() {
		if (returnTo.getMode() != ReturnTo.Original) {
			int slot = -1;

			if (returnTo.getMode() == ReturnTo.Slot) {
				List<Integer> slots = parseSlots(returnSlots.getValue());
				if (!slots.isEmpty())
					slot = slots.get(RNG.nextInt(slots.size()));
			} else if (!returnItems.getValue().isBlank()) {
				for (int i = 0; i < 9; i++) {
					ItemStack stack = mc.player.getInventory().getStack(i);
					if (!stack.isEmpty() && itemInList(stack.getItem(), returnItems.getValue())) {
						slot = i;
						break;
					}
				}
			}

			if (slot != -1)
				InventoryUtils.setInvSlot(slot);
		}

		restoreItemUse();
	}

	/** Echo: suspendItemUse. Right click (spear / shield) kuch der ke liye band, swap ke baad wapas. */
	private void suspendItemUse() {
		if (mc.player == null)
			return;

		if (mc.player.isUsingItem() || mc.options.useKey.isPressed()) {
			mc.options.useKey.setPressed(false);

			if (mc.player.isUsingItem()) {
				if (mc.player.getActiveHand() == Hand.OFF_HAND)
					mc.interactionManager.stopUsingItem(mc.player);
				else
					mc.player.clearActiveItem();
			}
		}

		if (!restoreUseKey && isUseKeyDown())
			restoreUseKey = true;
	}

	private void restoreItemUse() {
		if (!restoreUseKey)
			return;

		restoreUseKey = false;
		if (isUseKeyDown())
			mc.options.useKey.setPressed(true);
	}

	private boolean isUseKeyDown() {
		InputUtil.Key key = ((KeyBindingAccessor) mc.options.useKey).getBoundKey();
		if (key == null)
			return false;

		long handle = mc.getWindow().getHandle();
		if (key.getCategory() == InputUtil.Type.MOUSE)
			return GLFW.glfwGetMouseButton(handle, key.getCode()) == GLFW.GLFW_PRESS;

		return GLFW.glfwGetKey(handle, key.getCode()) == GLFW.GLFW_PRESS;
	}

	// ------------------------------------------------------------ mace choice

	private int findEligibleMace(LivingEntity target) {
		if (isOutsideWorld() || attackPending || pendingMaceSlot != -1 || swapActive) {
			debug("busy (pending swap)");
			return -1;
		}

		if (isUsingOffhand()) {
			debug("using offhand item");
			return -1;
		}

		if (!heldItemAllowed()) {
			debug("held item not in Item Whitelist");
			return -1;
		}

		if (!hotbarSlotAllowed()) {
			debug("current slot not in Hotbar Whitelist");
			return -1;
		}

		if (!isValidTarget(target)) {
			debug("invalid target");
			return -1;
		}

		// shield upar hai to axe ka kaam (Shield Breaker), mace nahi
		if (target instanceof PlayerEntity player && isBlockingTarget(player)) {
			debug("target is blocking with a shield");
			return -1;
		}

		int slot = findPriorityMace();
		if (slot == -1)
			return -1;

		if (mc.player.getInventory().getSelectedSlot() == slot) {
			debug("mace already in hand");
			return -1;
		}

		debug("swapping to slot " + (slot + 1));
		return slot;
	}

	private void debug(String message) {
		if (debug.getValue() && mc.player != null)
			mc.player.sendMessage(Text.literal("[Mace Swap] " + message), true);
	}

	private boolean isBlockingTarget(PlayerEntity player) {
		return player.isHolding(Items.SHIELD) && player.isBlocking() && !WorldUtils.isShieldFacingAway(player);
	}

	private boolean isUsingOffhand() {
		return mc.player.isUsingItem() && mc.player.getActiveHand() == Hand.OFF_HAND;
	}

	private boolean isValidTarget(LivingEntity entity) {
		return entity != null && entity != mc.player && entity.isAlive() && !entity.isRemoved()
				&& !entity.isDead() && !entity.isSpectator();
	}

	private int findPriorityMace() {
		float fallDistance = (float) mc.player.fallDistance;

		for (int index : parsePriority()) {
			if (!rangeContains(index, fallDistance))
				continue;

			int slot = findBestMace(enchantmentFor(index));
			if (slot != -1)
				return slot;
		}

		boolean anyMace = false;
		for (int i = 0; i < 9; i++)
			anyMace |= mc.player.getInventory().getStack(i).getItem() instanceof MaceItem;

		debug(anyMace
				? "no mace fits: fall " + String.format("%.1f", fallDistance) + " | check Priority Order + ranges (plain mace needs Fallback)"
				: "no mace in hotbar");
		return -1;
	}

	private boolean rangeContains(int index, float value) {
		MinMaxSetting range = rangeOf(index);
		float lower = range.getMinFloat();
		float upper = range.getMaxFloat();

		if (value < lower)
			return false;

		return !(upper < MAXIMUM_FALL_DISTANCE) || value < upper;
	}

	private MinMaxSetting rangeOf(int index) {
		return switch (index) {
			case 0 -> breachRange;
			case 1 -> windBurstRange;
			case 2 -> densityRange;
			default -> fallbackRange;
		};
	}

	private static RegistryKey<Enchantment> enchantmentFor(int index) {
		return switch (index) {
			case 0 -> Enchantments.BREACH;
			case 1 -> Enchantments.WIND_BURST;
			case 2 -> Enchantments.DENSITY;
			default -> null;
		};
	}

	/** Priority Order text -> indexes (0 Breach, 1 Wind Burst, 2 Density, 3 Fallback), upar se neeche. */
	private List<Integer> parsePriority() {
		List<Integer> order = new ArrayList<>();
		String text = priorityOrder.getValue();
		if (text == null)
			return order;

		for (String part : text.split("[,;>/|]+")) {
			String name = part.toLowerCase().replaceAll("[\\s_-]+", "");

			for (int i = 0; i < RANGE_NAMES.length; i++) {
				if (name.equals(RANGE_NAMES[i].toLowerCase().replace(" ", "")) && !order.contains(i))
					order.add(i);
			}
		}

		return order;
	}

	private int findBestMace(RegistryKey<Enchantment> enchantment) {
		List<Integer> enabled = parsePriority();
		int bestSlot = -1;
		int bestLevel = 0;

		for (int slot = 0; slot < 9; slot++) {
			ItemStack stack = mc.player.getInventory().getStack(slot);
			if (!(stack.getItem() instanceof MaceItem) || hasDisabledEnchantment(stack, enabled))
				continue;

			int level = enchantment == null
					? (hasNoConfiguredEnchantment(stack) ? 1 : 0)
					: getEnchantmentLevel(stack, enchantment);

			if (level > bestLevel) {
				bestSlot = slot;
				bestLevel = level;
			}
		}

		return bestSlot;
	}

	/** Priority Order mein na likhe enchant wala mace use nahi hota (Echo: disabled entry). */
	private boolean hasDisabledEnchantment(ItemStack stack, List<Integer> enabled) {
		for (int i = 0; i < 3; i++) {
			if (!enabled.contains(i) && getEnchantmentLevel(stack, enchantmentFor(i)) > 0)
				return true;
		}

		return false;
	}

	private boolean hasNoConfiguredEnchantment(ItemStack stack) {
		for (int i = 0; i < 3; i++) {
			if (getEnchantmentLevel(stack, enchantmentFor(i)) > 0)
				return false;
		}

		return true;
	}

	private static int getEnchantmentLevel(ItemStack stack, RegistryKey<Enchantment> enchantment) {
		ItemEnchantmentsComponent enchantments = stack.getOrDefault(DataComponentTypes.ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT);

		for (RegistryEntry<Enchantment> entry : enchantments.getEnchantments()) {
			if (entry.matchesKey(enchantment))
				return enchantments.getLevel(entry);
		}

		return 0;
	}

	// --------------------------------------------------------------- helpers

	private boolean heldItemAllowed() {
		String list = itemWhitelist.getValue();
		if (list == null || list.isBlank())
			return true;

		return itemInList(mc.player.getMainHandStack().getItem(), list);
	}

	private boolean hotbarSlotAllowed() {
		List<Integer> slots = parseSlots(hotbarWhitelist.getValue());
		return slots.isEmpty() || slots.contains(mc.player.getInventory().getSelectedSlot());
	}

	private static boolean itemInList(Item item, String list) {
		String path = Registries.ITEM.getId(item).getPath();

		for (String entry : list.toLowerCase().split("[,;\\s]+")) {
			if (entry.isEmpty())
				continue;

			if (entry.startsWith("minecraft:"))
				entry = entry.substring(10);

			if (entry.equals(path) || path.endsWith("_" + entry))
				return true;
		}

		return false;
	}

	private static List<Integer> parseSlots(String text) {
		List<Integer> slots = new ArrayList<>();
		if (text == null)
			return slots;

		for (String part : text.split("[,;\\s]+")) {
			try {
				int n = Integer.parseInt(part.trim());
				if (n >= 1 && n <= 9 && !slots.contains(n - 1))
					slots.add(n - 1);
			} catch (NumberFormatException ignored) {
			}
		}

		return slots;
	}

	/** Echo ke FloatRangeSetting.sampleGaussian jaisa: mean = beech, deviation = range / 6, range ke andar clamp. */
	private static float sample(MinMaxSetting setting) {
		float lower = setting.getMinFloat();
		float upper = setting.getMaxFloat();

		if (upper <= lower)
			return lower;

		float mean = (lower + upper) / 2.0f;
		float deviation = (upper - lower) / 6.0f;
		float value = (float) (RNG.nextGaussian() * deviation + mean);

		return Math.max(lower, Math.min(upper, value));
	}

	private static int sampleTicks(MinMaxSetting setting) {
		return Math.max(0, (int) sample(setting));
	}

	private boolean isOutsideWorld() {
		return mc.player == null || mc.world == null || mc.interactionManager == null;
	}

	private void clearScheduledSwap() {
		scheduledMaceSlot = -1;
		scheduledTargetId = -1;
		scheduledSwapTick = -1L;
	}

	private void resetPendingAttack() {
		pendingMaceSlot = -1;
		pendingTargetId = -1;
		requireSameTarget = true;
		attackPending = false;
		lastSwapTick = -1L;
	}

	private void resetAll() {
		swapActive = false;
		baselineSlot = -1;
		expireTick = 0L;
		switchBlocked = false;
		restoreUseKey = false;
		shieldClick = false;
		clearScheduledSwap();
		resetPendingAttack();
	}
}
