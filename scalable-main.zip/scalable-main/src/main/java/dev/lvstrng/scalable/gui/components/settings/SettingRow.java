package dev.lvstrng.scalable.gui.components.settings;

import dev.lvstrng.scalable.gui.Draw;
import dev.lvstrng.scalable.gui.Theme;
import dev.lvstrng.scalable.gui.Widgets;
import dev.lvstrng.scalable.module.setting.Setting;
import net.minecraft.client.input.CharInput;

/** Base class of every row in the settings panel. Positions are assigned by the panel every frame. */
public abstract class SettingRow {
	public final Setting<?> setting;
	public float x, y, w;
	/** False when the mouse is outside the visible part of the list. */
	public boolean hoverOk;
	protected float hover;

	protected SettingRow(Setting<?> setting) {
		this.setting = setting;
	}

	public abstract float height();

	public abstract void render(float mx, float my);

	/** Restores the default value (Backspace while hovering). */
	public abstract void reset();

	public boolean contains(float mx, float my) {
		return Widgets.inside(mx, my, x, y, w, height());
	}

	public boolean isHovered(float mx, float my) {
		return hoverOk && contains(mx, my);
	}

	/** @return true when the click was consumed. */
	public boolean mouseClicked(float mx, float my, int button) {
		return false;
	}

	public void mouseReleased(float mx, float my, int button) {
	}

	public void mouseDragged(float mx, float my) {
	}

	/** True while the row needs raw keyboard input (listening for a key / editing text). */
	public boolean wantsKeyboard() {
		return false;
	}

	public boolean keyPressed(int keyCode, int modifiers) {
		return false;
	}

	public boolean charTyped(CharInput input) {
		return false;
	}

	/** Called when the user clicks somewhere else. */
	public void blur() {
	}

	protected void drawBackground(float mx, float my) {
		hover = Theme.approach(hover, isHovered(mx, my) ? 1f : 0f, 14f);
		Draw.rrect(x, y, w, height(), Theme.rad(9f), Theme.white(9 + (int) (8 * hover)));
	}
}
