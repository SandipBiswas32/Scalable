package dev.lvstrng.scalable.gui;

import dev.lvstrng.scalable.module.modules.client.ClickGUI;
import dev.lvstrng.scalable.utils.Utils;

import java.awt.Color;

/** Colours, radii and animation helpers shared by every GUI component. */
public final class Theme {
	public static final int TEXT = 0xFFF2F2F6;
	public static final int TEXT_2 = 0xFF9C9CAB;
	public static final int TEXT_3 = 0xFF666673;
	public static final int OFF = 0xFF3B3B47;

	/** Current accent colour (follows the Client module colour settings). */
	public static int accent = 0xFF7C5CFF;

	private Theme() {}

	public static void update() {
		Color c = Utils.getMainColor(255, 0);
		accent = (0xFF << 24) | (c.getRGB() & 0xFFFFFF);
	}

	public static int white(int a) {
		return (a << 24) | 0xFFFFFF;
	}

	public static int black(int a) {
		return a << 24;
	}

	public static int accent(int a) {
		return (a << 24) | (accent & 0xFFFFFF);
	}

	public static int panel() {
		int a = Math.max(150, Math.min(255, ClickGUI.alphaWindow.getValueInt()));
		return (a << 24) | 0x0E0E13;
	}

	/** Scales a base corner radius with the "Roundness" setting (default 5 = 1x). */
	public static float rad(float base) {
		return base * (ClickGUI.roundQuads.getValueInt() / 5f);
	}

	public static int mix(int from, int to, float t) {
		t = Math.max(0f, Math.min(1f, t));
		int a = (int) (((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
		int r = (int) (((from >> 16) & 255) + (((to >> 16) & 255) - ((from >> 16) & 255)) * t);
		int g = (int) (((from >> 8) & 255) + (((to >> 8) & 255) - ((from >> 8) & 255)) * t);
		int b = (int) ((from & 255) + ((to & 255) - (from & 255)) * t);
		return (a << 24) | (r << 16) | (g << 8) | b;
	}

	/** Frame-rate independent smoothing. Snaps instantly when animations are turned off. */
	public static float approach(float current, float target, float speed) {
		if (ClickGUI.animationMode.isMode(ClickGUI.AnimationMode.Off))
			return target;

		float k = 1f - (float) Math.exp(-speed * Draw.dt);
		float next = current + (target - current) * k;
		return Math.abs(target - next) < 0.001f ? target : next;
	}

	public static float clamp(float v, float min, float max) {
		return Math.max(min, Math.min(max, v));
	}
}
