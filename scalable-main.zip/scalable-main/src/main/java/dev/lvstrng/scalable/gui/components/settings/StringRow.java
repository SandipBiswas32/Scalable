package dev.lvstrng.scalable.gui.components.settings;

import dev.lvstrng.scalable.gui.Draw;
import dev.lvstrng.scalable.gui.Theme;
import dev.lvstrng.scalable.gui.Widgets;
import dev.lvstrng.scalable.module.setting.StringSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.CharInput;
import org.lwjgl.glfw.GLFW;

/** Inline text field. */
public final class StringRow extends SettingRow {
	private final StringSetting setting;
	private final String original;
	private boolean editing;
	private float focus;

	public StringRow(StringSetting setting) {
		super(setting);
		this.setting = setting;
		this.original = setting.getValue();
	}

	@Override
	public float height() {
		return 70f;
	}

	@Override
	public boolean wantsKeyboard() {
		return editing;
	}

	private float fieldX() {
		return x + 12f;
	}

	private float fieldY() {
		return y + 32f;
	}

	private float fieldW() {
		return w - 24f;
	}

	private static final float FIELD_H = 28f;

	@Override
	public void render(float mx, float my) {
		drawBackground(mx, my);
		focus = Theme.approach(focus, editing ? 1f : 0f, 16f);

		Draw.text(Draw.fit(setting.getName(), 0.62f, w - 28f), x + 14f, y + 18f, 0.62f, Theme.TEXT);

		float fx = fieldX(), fy = fieldY(), fw = fieldW();
		Draw.rrect(fx, fy, fw, FIELD_H, Theme.rad(8f), Theme.black(90));
		Draw.outline(fx, fy, fw, FIELD_H, Theme.rad(8f), Theme.mix(Theme.white(14), Theme.accent(220), focus));

		String value = setting.getValue() == null ? "" : setting.getValue();
		float maxW = fw - 22f;
		float cy = fy + FIELD_H / 2f;

		if (editing) {
			String shown = Draw.fitTail(value, 0.56f, maxW);
			Draw.text(shown, fx + 11f, cy, 0.56f, Theme.TEXT);
			if ((System.currentTimeMillis() / 500L) % 2L == 0L)
				Draw.rect(fx + 11f + Draw.textW(shown, 0.56f) + 1f, cy - 8f, 1.5f, 16f, Theme.accent);
		} else if (value.isEmpty()) {
			Draw.text("Click to edit", fx + 11f, cy, 0.56f, Theme.TEXT_3);
		} else {
			Draw.text(Draw.fit(value, 0.56f, maxW), fx + 11f, cy, 0.56f, Theme.TEXT_2);
		}
	}

	@Override
	public boolean mouseClicked(float mx, float my, int button) {
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && Widgets.inside(mx, my, fieldX(), fieldY(), fieldW(), FIELD_H) && (editing || contains(mx, my))) {
			editing = true;
			return true;
		}
		return false;
	}

	@Override
	public boolean keyPressed(int keyCode, int modifiers) {
		if (!editing) return false;

		if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
			editing = false;
			setting.setValue(setting.getValue().strip());
			return true;
		}

		if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
			String v = setting.getValue();
			if (!v.isEmpty()) setting.setValue(v.substring(0, v.length() - 1));
			return true;
		}

		boolean ctrl = (modifiers & GLFW.GLFW_MOD_CONTROL) != 0;
		if (ctrl && keyCode == GLFW.GLFW_KEY_V) {
			setting.setValue(setting.getValue() + MinecraftClient.getInstance().keyboard.getClipboard());
			return true;
		}
		if (ctrl && keyCode == GLFW.GLFW_KEY_C) {
			MinecraftClient.getInstance().keyboard.setClipboard(setting.getValue());
			return true;
		}

		return true; // swallow everything else while typing
	}

	@Override
	public boolean charTyped(CharInput input) {
		if (!editing || !input.isValidChar()) return false;
		setting.setValue(setting.getValue() + input.asString());
		return true;
	}

	@Override
	public void blur() {
		if (editing) {
			editing = false;
			setting.setValue(setting.getValue().strip());
		}
	}

	@Override
	public void reset() {
		setting.setValue(original);
	}
}
