package dev.lvstrng.scalable.gui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.font.LineMetrics;
import java.awt.font.TextAttribute;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Pure-Java rasteriser for the GUI (no Minecraft classes in here).
 * <p>
 * Text is rendered at the exact pixel size it is going to be shown at, so it is never scaled down
 * (scaling a big texture down was what made the old font look thin, shimmery and unclear).
 */
public final class GlyphBaker {
	/** Em size (px) that all layout widths are measured at. Text widths in the GUI scale linearly from this. */
	public static final float REF_EM = 20f;

	/**
	 * Font weight boost. Extra stem thickness as a fraction of the em size.
	 * 0 = original Quicksand Regular, 0.03 = medium, 0.05 = semi-bold, 0.08 = bold.
	 */
	public static final float BOLD = 0.05f;

	/** Distance of the text baseline below the vertical centre line, as a fraction of the em size. */
	public static final float BASELINE_K = 0.28f;

	private static final FontRenderContext FRC = new FontRenderContext(null, true, true);
	private static final Map<Integer, Font> FONTS = new HashMap<>();
	private static Font base;

	private GlyphBaker() {}

	private static synchronized Font base() {
		if (base == null) {
			try (InputStream in = GlyphBaker.class.getResourceAsStream("/assets/scalable/font/font.ttf")) {
				base = Font.createFont(Font.TRUETYPE_FONT, in);
			} catch (Throwable t) {
				t.printStackTrace();
				base = new Font(Font.SANS_SERIF, Font.PLAIN, 1);
			}
			Map<TextAttribute, Object> attrs = new HashMap<>();
			attrs.put(TextAttribute.KERNING, TextAttribute.KERNING_ON);
			base = base.deriveFont(attrs);
		}
		return base;
	}

	private static synchronized Font font(float em) {
		int key = Math.round(em * 4f);
		Font f = FONTS.get(key);
		if (f == null) {
			f = base().deriveFont(key / 4f);
			FONTS.put(key, f);
		}
		return f;
	}

	/** Advance width of the string at {@link #REF_EM}. */
	public static float measure(String s) {
		if (s == null || s.isEmpty()) return 0f;
		GlyphVector gv = font(REF_EM).createGlyphVector(FRC, s);
		return (float) gv.getLogicalBounds().getWidth();
	}

	public static final class Baked {
		public final BufferedImage img;
		/** Horizontal padding: draw the image at (textX - pad). */
		public final int pad;
		/** Distance from the top of the image to the baseline: draw the image at (baselineY - baseOff). */
		public final int baseOff;

		Baked(BufferedImage img, int pad, int baseOff) {
			this.img = img;
			this.pad = pad;
			this.baseOff = baseOff;
		}
	}

	private static void hints(Graphics2D g) {
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
		g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
	}

	public static Baked text(String s, float em) {
		Font f = font(em);
		GlyphVector gv = f.createGlyphVector(FRC, s);
		Rectangle2D lb = gv.getLogicalBounds();
		LineMetrics lm = f.getLineMetrics(s, FRC);

		float stroke = em * BOLD;
		int pad = (int) Math.ceil(stroke) + 2;
		int ascent = (int) Math.ceil(lm.getAscent());
		int descent = (int) Math.ceil(lm.getDescent());
		int w = Math.max(1, (int) Math.ceil(lb.getWidth()) + pad * 2);
		int h = Math.max(1, ascent + descent + pad * 2);

		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = img.createGraphics();
		hints(g);
		g.setColor(Color.WHITE);

		Shape outline = gv.getOutline(pad, pad + ascent);
		g.fill(outline);
		if (stroke > 0.01f) {
			g.setStroke(new BasicStroke(stroke, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
			g.draw(outline);
		}
		g.dispose();

		return new Baked(img, pad, pad + ascent);
	}

	private static float clamp01(float v) {
		return v < 0f ? 0f : Math.min(v, 1f);
	}

	/** Anti-aliased filled circle, diameter 2r. */
	public static BufferedImage disc(int r) {
		return ring(r, 0);
	}

	/** Anti-aliased ring (outer radius r, thickness t; t = 0 gives a filled disc), size 2r x 2r. */
	public static BufferedImage ring(int r, int t) {
		int size = Math.max(2, r * 2);
		float inner = t <= 0 ? -1f : Math.max(0f, r - t);
		BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
		float c = size / 2f;
		for (int y = 0; y < size; y++) {
			for (int x = 0; x < size; x++) {
				float dx = x + 0.5f - c, dy = y + 0.5f - c;
				float d = (float) Math.sqrt(dx * dx + dy * dy);
				float a = clamp01(r - d + 0.5f);
				if (inner >= 0f) a -= clamp01(inner - d + 0.5f);
				int ai = Math.round(clamp01(a) * 255f);
				img.setRGB(x, y, (ai << 24) | 0xFFFFFF);
			}
		}
		return img;
	}
}
