package dev.lvstrng.scalable.gui.components.settings;

import dev.lvstrng.scalable.gui.Draw;
import dev.lvstrng.scalable.gui.Theme;
import dev.lvstrng.scalable.module.Module;
import dev.lvstrng.scalable.module.setting.KeybindSetting;
import dev.lvstrng.scalable.utils.KeyUtils;
import org.lwjgl.glfw.GLFW;

public final class KeybindRow extends SettingRow {
	private final KeybindSetting setting;
	private final Module module;
	private float listen;

	public KeybindRow(Module module, KeybindSetting setting) {
		super(setting);
		this.module = module;
		this.setting = setting;
	}

	@Override
	public float height() {
		return 46f;
	}

	@Override
	public boolean wantsKeyboard() {
		return setting.isListening();
	}

	private void bind(int key) {
		if (setting.isModuleKey()) module.setKey(key);
		setting.setKey(key);
		setting.setListening(false);
	}

	@Override
	public void render(float mx, float my) {
		drawBackground(mx, my);
		listen = Theme.approach(listen, setting.isListening() ? 1f : 0f, 16f);

		String label = setting.isListening() ? "Press a key..." : KeyUtils.getKey(setting.getKey()).toString();
		float pw = Math.max(84f, Draw.textW(label, 0.56f) + 30f);
		float ph = 28f;
		float px = x + w - 12f - pw, py = y + (height() - ph) / 2f;

		Draw.text(Draw.fit(setting.getName(), 0.62f, w - pw - 40f), x + 14f, y + height() / 2f, 0.62f, Theme.TEXT);

		Draw.rrect(px, py, pw, ph, Theme.rad(8f), Theme.mix(Theme.white(16), Theme.accent(60), listen));
		if (listen > 0.01f)
			Draw.outline(px, py, pw, ph, Theme.rad(8f), Theme.accent((int) (200 * listen)));
		Draw.textCentered(label, px + pw / 2f, py + ph / 2f, 0.56f, Theme.mix(Theme.TEXT_2, Theme.TEXT, Math.max(listen, hover)));
	}

	@Override
	public boolean mouseClicked(float mx, float my, int button) {
		if (setting.isListening()) {
			// middle / side mouse buttons can be bound, left & right just cancel
			if (button >= GLFW.GLFW_MOUSE_BUTTON_MIDDLE) bind(button);
			else setting.setListening(false);
			return true;
		}

		if (contains(mx, my) && button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
			setting.setListening(true);
			return true;
		}
		return false;
	}

	@Override
	public boolean keyPressed(int keyCode, int modifiers) {
		if (!setting.isListening()) return false;

		if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
			setting.setListening(false);
		} else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
			reset();
		} else {
			bind(keyCode);
		}
		return true;
	}

	@Override
	public void blur() {
		setting.setListening(false);
	}

	@Override
	public void reset() {
		bind(setting.getOriginalKey());
	}
}
