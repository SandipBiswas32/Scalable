package dev.lvstrng.scalable.gui.components.settings;

import dev.lvstrng.scalable.gui.Draw;
import dev.lvstrng.scalable.gui.Theme;
import dev.lvstrng.scalable.gui.Widgets;
import dev.lvstrng.scalable.module.setting.ModeSetting;
import org.lwjgl.glfw.GLFW;

public final class ModeRow extends SettingRow {
	private final ModeSetting<?> setting;
	private float pillHover;

	public ModeRow(ModeSetting<?> setting) {
		super(setting);
		this.setting = setting;
	}

	@Override
	public float height() {
		return 46f;
	}

	private float pillW() {
		return Math.max(84f, Draw.textW(setting.getMode().name(), 0.56f) + 44f);
	}

	@Override
	public void render(float mx, float my) {
		drawBackground(mx, my);

		float pw = pillW(), ph = 28f;
		float px = x + w - 12f - pw, py = y + (height() - ph) / 2f;
		pillHover = Theme.approach(pillHover, isHovered(mx, my) && Widgets.inside(mx, my, px, py, pw, ph) ? 1f : 0f, 16f);

		Draw.text(Draw.fit(setting.getName(), 0.62f, w - pw - 40f), x + 14f, y + height() / 2f, 0.62f, Theme.TEXT);

		Draw.rrect(px, py, pw, ph, Theme.rad(8f), Theme.white(16 + (int) (12 * pillHover)));
		Draw.textCentered(setting.getMode().name(), px + pw / 2f, py + ph / 2f, 0.56f, Theme.TEXT);
		Draw.text("<", px + 10f, py + ph / 2f, 0.5f, Theme.mix(Theme.TEXT_3, Theme.accent, pillHover));
		Draw.textRight(">", px + pw - 10f, py + ph / 2f, 0.5f, Theme.mix(Theme.TEXT_3, Theme.accent, pillHover));
	}

	@Override
	public boolean mouseClicked(float mx, float my, int button) {
		if (!contains(mx, my)) return false;
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
			setting.cycle();
			return true;
		}
		if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
			setting.cycleBack();
			return true;
		}
		return false;
	}

	@Override
	public void reset() {
		setting.setModeIndex(setting.getOriginalValue());
	}
}
