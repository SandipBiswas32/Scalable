package dev.lvstrng.scalable.module;

import dev.lvstrng.scalable.utils.EncryptedString;

public enum Category {
	COMBAT(EncryptedString.of("Combat")),
	CLIENT(EncryptedString.of("Client"));
	public final CharSequence name;

	Category(CharSequence name) {
		this.name = name;
	}
}
