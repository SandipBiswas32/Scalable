package dev.lvstrng.scalable.event;

import java.util.EventListener;

public interface Listener extends EventListener {
}
