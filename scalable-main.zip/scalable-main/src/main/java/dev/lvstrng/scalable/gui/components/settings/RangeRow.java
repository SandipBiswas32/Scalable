package dev.lvstrng.scalable.gui.components.settings;

import dev.lvstrng.scalable.gui.Draw;
import dev.lvstrng.scalable.gui.Theme;
import dev.lvstrng.scalable.module.setting.MinMaxSetting;
import dev.lvstrng.scalable.utils.MathUtils;
import org.lwjgl.glfw.GLFW;

/** Slider with two handles (min / max). */
public final class RangeRow extends SettingRow {
	private static final float PAD = 14f;

	private final MinMaxSetting setting;
	/** -1 = not dragging, 0 = min handle, 1 = max handle */
	private int active = -1;
	private float shownMin, shownMax;

	public RangeRow(MinMaxSetting setting) {
		super(setting);
		this.setting = setting;
		this.shownMin = frac(setting.getMinValue());
		this.shownMax = frac(setting.getMaxValue());
	}

	@Override
	public float height() {
		return 58f;
	}

	private float frac(double v) {
		double range = setting.getMax() - setting.getMin();
		if (range <= 0) return 0f;
		return Theme.clamp((float) ((v - setting.getMin()) / range), 0f, 1f);
	}

	private float trackX() {
		return x + PAD;
	}

	private float trackW() {
		return w - PAD * 2f;
	}

	private float trackY() {
		return y + 42f;
	}

	@Override
	public void render(float mx, float my) {
		drawBackground(mx, my);
		shownMin = Theme.approach(shownMin, frac(setting.getMinValue()), 18f);
		shownMax = Theme.approach(shownMax, frac(setting.getMaxValue()), 18f);

		Draw.text(Draw.fit(setting.getName(), 0.62f, w - 150f), x + PAD, y + 19f, 0.62f, Theme.TEXT);
		String value = SliderRow.format(setting.getMinValue(), setting.getIncrement()) + "  -  " + SliderRow.format(setting.getMaxValue(), setting.getIncrement());
		Draw.textRight(value, x + w - PAD, y + 19f, 0.58f, Theme.mix(Theme.TEXT_2, Theme.accent, active >= 0 ? 1f : 0.55f));

		float tx = trackX(), tw = trackW(), ty = trackY();
		Draw.rrect(tx, ty - 3f, tw, 6f, 3f, Theme.white(22));

		float a = tx + tw * shownMin;
		float b = tx + tw * shownMax;
		Draw.rrect(a, ty - 3f, Math.max(4f, b - a), 6f, 3f, Theme.accent);

		for (int i = 0; i < 2; i++) {
			float kx = i == 0 ? a : b;
			float kr = active == i ? 8f : 7f;
			Draw.circle(kx, ty + 0.5f, kr + 1f, Theme.black(70));
			Draw.circle(kx, ty, kr, 0xFFFFFFFF);
			Draw.circle(kx, ty, kr - 3.5f, Theme.accent);
		}
	}

	private double valueAt(float mx) {
		double b = Theme.clamp((mx - trackX()) / trackW(), 0f, 1f);
		return MathUtils.roundToDecimal(b * (setting.getMax() - setting.getMin()) + setting.getMin(), setting.getIncrement());
	}

	private void apply(float mx) {
		double v = valueAt(mx);
		if (active == 0) setting.setMinValue(Math.min(v, setting.getMaxValue()));
		else if (active == 1) setting.setMaxValue(Math.max(v, setting.getMinValue()));
	}

	@Override
	public boolean mouseClicked(float mx, float my, int button) {
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && contains(mx, my) && my >= y + 24f) {
			float a = trackX() + trackW() * shownMin;
			float b = trackX() + trackW() * shownMax;
			// pick the nearest handle (if both overlap, pick by side)
			if (Math.abs(mx - a) == Math.abs(mx - b)) active = mx < a ? 0 : 1;
			else active = Math.abs(mx - a) < Math.abs(mx - b) ? 0 : 1;
			apply(mx);
			return true;
		}
		return false;
	}

	@Override
	public void mouseDragged(float mx, float my) {
		if (active >= 0) apply(mx);
	}

	@Override
	public void mouseReleased(float mx, float my, int button) {
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) active = -1;
	}

	@Override
	public void blur() {
		active = -1;
	}

	@Override
	public void reset() {
		setting.setMinValue(setting.getOriginalMinValue());
		setting.setMaxValue(setting.getOriginalMaxValue());
	}
}
